import React from 'react';
import { X, ShieldCheck, Lock, EyeOff, Server, FileText } from 'lucide-react';

interface PrivacyNoticeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PrivacyNoticeModal: React.FC<PrivacyNoticeModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-2xl rounded-2xl border border-white/10 bg-[#0D1320] p-6 shadow-2xl space-y-5">
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center space-x-2">
            <div className="rounded-lg bg-emerald-500/10 p-1.5 text-emerald-400">
              <Lock className="h-5 w-5" />
            </div>
            <h3 className="text-lg font-bold text-white">Privacy-by-Design & Compliance Notice</h3>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1 text-slate-400 hover:text-white hover:bg-white/10 transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="space-y-4 text-xs text-slate-300 leading-relaxed max-h-[70vh] overflow-y-auto pr-1">
          <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/5 p-3.5">
            <span className="font-semibold text-emerald-300 block mb-1">
              Zero Sensitive Data Storage
            </span>
            <p>
              This platform adheres to strict data-minimization guidelines. We never collect or
              store sensitive personally identifiable information (PII) such as Social Security
              Numbers, national identity numbers, bank login credentials, or account passwords.
            </p>
          </div>

          <div className="space-y-2">
            <h4 className="font-semibold text-white flex items-center space-x-1.5">
              <EyeOff className="h-4 w-4 text-cyan-400" />
              <span>What Information is Collected & Why</span>
            </h4>
            <ul className="list-disc list-inside space-y-1 text-slate-400">
              <li>
                <strong className="text-slate-300">Financial Figures (Income, Expenses, EMI):</strong>{' '}
                Used solely to compute disposable cash cushions, debt burden ratios (FOIR/DTI), and
                estimated borrowing capacities.
              </li>
              <li>
                <strong className="text-slate-300">Self-Reported Credit Score:</strong> Used to
                approximate lender risk tiers without triggering hard inquiries on your bureau file.
              </li>
              <li>
                <strong className="text-slate-300">Saved Records:</strong> Optional assessment
                snapshots stored in your designated Google Sheets instance or private local server
                cache for your personal financial planning.
              </li>
            </ul>
          </div>

          <div className="space-y-2">
            <h4 className="font-semibold text-white flex items-center space-x-1.5">
              <Server className="h-4 w-4 text-indigo-400" />
              <span>Architecture & Security Safeguards</span>
            </h4>
            <p className="text-slate-400">
              All interactions with external AI models (Gemini / Claude) and Google Sheets APIs are
              strictly brokered server-side. Secret API keys and service account credentials never
              touch the browser runtime or client-side JavaScript.
            </p>
          </div>

          <div className="rounded-xl border border-white/10 bg-white/[0.02] p-3 text-[11px] text-slate-400">
            <strong className="text-slate-300">Right to Erasure:</strong> You can purge individual
            or all financial scenarios at any time via the Financial Records panel.
          </div>
        </div>

        <div className="pt-3 border-t border-white/10 flex justify-end">
          <button
            onClick={onClose}
            className="rounded-xl bg-indigo-600 px-4 py-2 text-xs font-semibold text-white hover:bg-indigo-500 transition"
          >
            I Understand & Agree
          </button>
        </div>
      </div>
    </div>
  );
};
