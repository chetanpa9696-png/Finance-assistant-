import React from 'react';
import { X, FileText, Calculator, Scale, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { SCORING_CONFIG } from '../utils/calculations';

interface MethodologyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MethodologyModal: React.FC<MethodologyModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-2xl rounded-2xl border border-white/10 bg-[#0D1320] p-6 shadow-2xl space-y-5">
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center space-x-2">
            <div className="rounded-lg bg-indigo-500/10 p-1.5 text-indigo-400">
              <FileText className="h-5 w-5" />
            </div>
            <h3 className="text-lg font-bold text-white">
              Underwriting & Mathematical Methodology
            </h3>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1 text-slate-400 hover:text-white hover:bg-white/10 transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="space-y-5 text-xs text-slate-300 leading-relaxed max-h-[70vh] overflow-y-auto pr-1">
          {/* 1. EMI Formula */}
          <div className="rounded-xl border border-white/10 bg-white/[0.02] p-3.5 space-y-2">
            <h4 className="font-semibold text-white flex items-center space-x-1.5">
              <Calculator className="h-4 w-4 text-emerald-400" />
              <span>1. Standard Equated Monthly Installment (EMI) Formula</span>
            </h4>
            <div className="bg-slate-950 p-2.5 rounded-lg font-mono text-cyan-300 text-[11px]">
              EMI = [ P × r × (1 + r)^n ] / [ (1 + r)^n - 1 ]
            </div>
            <ul className="text-[11px] text-slate-400 space-y-0.5">
              <li>• <strong className="text-slate-300">P</strong> = Principal loan amount</li>
              <li>• <strong className="text-slate-300">r</strong> = Monthly interest rate (Annual Rate ÷ 12 ÷ 100)</li>
              <li>• <strong className="text-slate-300">n</strong> = Total tenure in months</li>
              <li>• <strong className="text-slate-300">Zero-Interest Clause:</strong> When r = 0, EMI = P ÷ n</li>
            </ul>
          </div>

          {/* 2. Disposable Income & FOIR */}
          <div className="rounded-xl border border-white/10 bg-white/[0.02] p-3.5 space-y-2">
            <h4 className="font-semibold text-white flex items-center space-x-1.5">
              <Scale className="h-4 w-4 text-indigo-400" />
              <span>2. Disposable Cash Flow & Fixed Obligation Ratio (FOIR)</span>
            </h4>
            <div className="bg-slate-950 p-2.5 rounded-lg font-mono text-indigo-300 text-[11px] space-y-1">
              <div>Disposable Income = Monthly Income - Monthly Expenses - Existing EMIs</div>
              <div>Max Allowable New EMI = (Monthly Income × 50%) - Existing EMIs</div>
            </div>
            <p className="text-[11px] text-slate-400">
              In retail banking, total debt commitments must not exceed 50% of verifiable net
              income (FOIR cap). The maximum loan principal is calculated by discounting the maximum
              allowable EMI over the requested tenure at benchmark interest rates.
            </p>
          </div>

          {/* 3. Multi-Factor Scoring Weighting */}
          <div className="rounded-xl border border-white/10 bg-white/[0.02] p-3.5 space-y-2">
            <h4 className="font-semibold text-white flex items-center space-x-1.5">
              <ShieldCheck className="h-4 w-4 text-cyan-400" />
              <span>3. Factor Weighting in Loan Eligibility Score</span>
            </h4>
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div className="p-2 rounded bg-white/5 flex justify-between">
                <span>Credit Score Factor:</span>
                <strong className="text-white">{SCORING_CONFIG.WEIGHTS.CREDIT_SCORE}%</strong>
              </div>
              <div className="p-2 rounded bg-white/5 flex justify-between">
                <span>Debt Burden (DTI) Factor:</span>
                <strong className="text-white">{SCORING_CONFIG.WEIGHTS.DEBT_BURDEN_DTI}%</strong>
              </div>
              <div className="p-2 rounded bg-white/5 flex justify-between">
                <span>Income Stability & Buffer:</span>
                <strong className="text-white">{SCORING_CONFIG.WEIGHTS.INCOME_STABILITY}%</strong>
              </div>
              <div className="p-2 rounded bg-white/5 flex justify-between">
                <span>Employment Profile & Tenure:</span>
                <strong className="text-white">{SCORING_CONFIG.WEIGHTS.EMPLOYMENT_PROFILE}%</strong>
              </div>
              <div className="p-2 rounded bg-white/5 flex justify-between">
                <span>Age & Retirement Alignment:</span>
                <strong className="text-white">{SCORING_CONFIG.WEIGHTS.AGE_TENURE_ALIGNMENT}%</strong>
              </div>
              <div className="p-2 rounded bg-white/5 flex justify-between">
                <span>Loan Affordability:</span>
                <strong className="text-white">{SCORING_CONFIG.WEIGHTS.DESIRED_LOAN_AFFORDABILITY}%</strong>
              </div>
            </div>
          </div>
        </div>

        <div className="pt-3 border-t border-white/10 flex justify-end">
          <button
            onClick={onClose}
            className="rounded-xl bg-indigo-600 px-4 py-2 text-xs font-semibold text-white hover:bg-indigo-500 transition"
          >
            Close Methodology
          </button>
        </div>
      </div>
    </div>
  );
};
