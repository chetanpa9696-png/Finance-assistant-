import React, { useState } from 'react';
import {
  Sparkles,
  RefreshCw,
  Send,
  AlertCircle,
  CheckCircle2,
  TrendingUp,
  ShieldCheck,
  PiggyBank,
  FileCheck,
  Copy,
  Check,
  Download,
  Info,
} from 'lucide-react';
import { FinancialProfile, Currency, AIAdvisoryResult } from '../types';
import { formatCurrency } from '../utils/formatters';

interface AITipsViewProps {
  profile: FinancialProfile;
  currency: Currency;
  onUpdateProfile: (updated: Partial<FinancialProfile>) => void;
}

export const AITipsView: React.FC<AITipsViewProps> = ({
  profile,
  currency,
  onUpdateProfile,
}) => {
  const [financialGoals, setFinancialGoals] = useState<string>(
    profile.financialGoals || 'Seeking prime mortgage approval with minimal long-term interest.'
  );
  const [savingsBalance, setSavingsBalance] = useState<number>(profile.savingsBalance || 35000);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [advisoryResult, setAdvisoryResult] = useState<AIAdvisoryResult | null>(null);
  const [copied, setCopied] = useState<boolean>(false);

  const handleGenerateAdvice = async () => {
    setIsLoading(true);
    setError(null);

    // Update parent profile with current savings and goal
    onUpdateProfile({ financialGoals, savingsBalance });

    try {
      const response = await fetch('/api/ai-advisor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          income: profile.monthlyIncome,
          expenses: profile.monthlyExpenses,
          existingDebt: profile.outstandingDebt || profile.existingEmi * 24,
          emi: profile.existingEmi,
          creditScore: profile.creditScore,
          savings: savingsBalance,
          financialGoals: financialGoals,
          loanRequirements: {
            amount: profile.desiredLoanAmount,
            tenureMonths: profile.loanTenureMonths,
            employmentType: profile.employmentType,
          },
          currency,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to fetch AI recommendations');
      }

      const data: AIAdvisoryResult = await response.json();
      setAdvisoryResult(data);
    } catch (err: unknown) {
      console.error('AI Advisory request error:', err);
      setError('The AI assistant is temporarily unavailable. Please try again later.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = () => {
    if (!advisoryResult) return;
    const text = `
BFSI FINDECISION AI FINANCIAL ADVISORY
Generated: ${new Date().toLocaleDateString()}

EXECUTIVE SUMMARY:
${advisoryResult.executiveSummary}

SPENDING OBSERVATIONS:
${advisoryResult.spendingObservations.map((o) => `• ${o}`).join('\n')}

DEBT MANAGEMENT:
${advisoryResult.debtManagementAdvice.map((d) => `• ${d}`).join('\n')}

CREDIT ENHANCEMENT ROADMAP:
${advisoryResult.creditImprovementChecklist.map((c) => `• ${c}`).join('\n')}

EMI AFFORDABILITY:
${advisoryResult.emiAffordabilityGuidance}

POTENTIAL RISKS:
${advisoryResult.potentialRisks.map((r) => `• ${r}`).join('\n')}

DISCLAIMER:
${advisoryResult.disclaimer}
    `.trim();

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Header */}
      <div className="border-b border-white/10 pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center space-x-2">
            <Sparkles className="h-6 w-6 text-indigo-400" />
            <h2 className="text-2xl font-bold tracking-tight text-white">
              AI Financial Advisory & Decision Insights
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Personalized financial guidance, cash flow stress-testing, credit-risk analysis, and
            structured loan readiness roadmaps.
          </p>
        </div>

        {advisoryResult && (
          <div className="flex items-center space-x-2">
            <button
              onClick={handleCopy}
              className="flex items-center space-x-1.5 rounded-xl border border-white/10 bg-white/5 px-3 py-1.5 text-xs text-slate-300 hover:bg-white/10 transition"
            >
              {copied ? (
                <>
                  <Check className="h-3.5 w-3.5 text-emerald-400" />
                  <span className="text-emerald-400">Copied</span>
                </>
              ) : (
                <>
                  <Copy className="h-3.5 w-3.5 text-slate-400" />
                  <span>Copy Report</span>
                </>
              )}
            </button>
          </div>
        )}
      </div>

      {/* Advisory Inputs Form Card */}
      <div className="rounded-2xl border border-white/10 bg-[#0D1320]/80 p-6 backdrop-blur-xl shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-white/10 pb-3">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-white">
            Contextual Financial Objectives & Liquid Reserves
          </h3>
          <span className="text-[11px] text-cyan-400 font-medium">
            Profile: {profile.fullName || 'Active Applicant'}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
          <div className="md:col-span-4">
            <label
              htmlFor="savings-balance-input"
              className="block text-xs font-medium text-slate-300 mb-1"
            >
              Liquid Savings & Emergency Reserve ({currency})
            </label>
            <input
              id="savings-balance-input"
              type="number"
              min={0}
              step={1000}
              value={savingsBalance}
              onChange={(e) => setSavingsBalance(Math.max(0, Number(e.target.value)))}
              className="w-full rounded-xl border border-white/15 bg-white/5 px-3.5 py-2.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition"
              placeholder="35000"
            />
          </div>

          <div className="md:col-span-8">
            <label
              htmlFor="financial-goals-input"
              className="block text-xs font-medium text-slate-300 mb-1"
            >
              Primary Financial Target / Borrowing Context
            </label>
            <input
              id="financial-goals-input"
              type="text"
              value={financialGoals}
              onChange={(e) => setFinancialGoals(e.target.value)}
              className="w-full rounded-xl border border-white/15 bg-white/5 px-3.5 py-2.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition"
              placeholder="e.g. Planning a home purchase with minimal long-term interest strain."
            />
          </div>
        </div>

        {/* Snapshot Summary pills */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 text-[11px] text-slate-400">
          <div className="rounded-lg bg-white/[0.02] border border-white/5 p-2">
            <span>Income: </span>
            <strong className="text-white">{formatCurrency(profile.monthlyIncome, currency)}</strong>
          </div>
          <div className="rounded-lg bg-white/[0.02] border border-white/5 p-2">
            <span>Outlays: </span>
            <strong className="text-white">
              {formatCurrency(profile.monthlyExpenses + profile.existingEmi, currency)}
            </strong>
          </div>
          <div className="rounded-lg bg-white/[0.02] border border-white/5 p-2">
            <span>Credit Score: </span>
            <strong className="text-cyan-300">{profile.creditScore}</strong>
          </div>
          <div className="rounded-lg bg-white/[0.02] border border-white/5 p-2">
            <span>Desired Loan: </span>
            <strong className="text-emerald-400">
              {formatCurrency(profile.desiredLoanAmount, currency)}
            </strong>
          </div>
        </div>

        <div className="pt-2">
          <button
            id="generate-ai-advice-btn"
            onClick={handleGenerateAdvice}
            disabled={isLoading}
            className="flex items-center justify-center space-x-2 w-full sm:w-auto rounded-xl bg-gradient-to-r from-indigo-600 via-indigo-500 to-cyan-600 px-6 py-3 text-sm font-semibold text-white shadow-lg shadow-indigo-500/25 hover:from-indigo-500 hover:to-cyan-500 transition disabled:opacity-50"
          >
            {isLoading ? (
              <>
                <RefreshCw className="h-4 w-4 animate-spin text-cyan-300" />
                <span>Generating Comprehensive AI Assessment...</span>
              </>
            ) : (
              <>
                <Sparkles className="h-4 w-4 text-cyan-300" />
                <span>
                  {advisoryResult ? 'Regenerate Advisory Report' : 'Consult AI Financial Advisor'}
                </span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Error state */}
      {error && (
        <div className="rounded-2xl border border-rose-500/30 bg-rose-500/10 p-4 text-xs text-rose-300 flex items-center space-x-3">
          <AlertCircle className="h-5 w-5 text-rose-400 flex-shrink-0" />
          <div className="flex-1">
            <p className="font-semibold">Service Notice</p>
            <p>{error}</p>
          </div>
          <button
            onClick={handleGenerateAdvice}
            className="rounded-lg bg-rose-500/20 border border-rose-500/40 px-3 py-1 font-semibold text-white hover:bg-rose-500/30 transition"
          >
            Retry
          </button>
        </div>
      )}

      {/* Loading Skeleton */}
      {isLoading && !advisoryResult && (
        <div className="rounded-2xl border border-white/10 bg-[#0D1320]/80 p-8 backdrop-blur-xl shadow-xl space-y-6 animate-pulse">
          <div className="h-5 w-48 bg-white/10 rounded-md" />
          <div className="space-y-2">
            <div className="h-3 w-full bg-white/10 rounded-md" />
            <div className="h-3 w-5/6 bg-white/10 rounded-md" />
            <div className="h-3 w-4/6 bg-white/10 rounded-md" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4">
            <div className="h-32 bg-white/5 rounded-xl" />
            <div className="h-32 bg-white/5 rounded-xl" />
          </div>
        </div>
      )}

      {/* Advisory Result Content */}
      {advisoryResult && (
        <div className="space-y-6">
          {/* Executive Summary */}
          <div className="rounded-2xl border border-indigo-500/30 bg-gradient-to-b from-indigo-500/10 via-[#0D1320] to-[#0D1320] p-6 backdrop-blur-xl shadow-xl">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <span className="text-xs font-semibold text-cyan-400 uppercase tracking-wider flex items-center space-x-1.5">
                <Sparkles className="h-3.5 w-3.5" />
                <span>Executive Financial Assessment</span>
              </span>
              <span className="text-[10px] text-slate-400">
                Engine: {advisoryResult.modelUsed || 'AI Advisor'}
              </span>
            </div>
            <p className="mt-4 text-sm text-slate-200 leading-relaxed">
              {advisoryResult.executiveSummary}
            </p>
          </div>

          {/* 4 Multi-Dimension Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* 1. Spending & Cash Flow Observations */}
            <div className="rounded-2xl border border-white/10 bg-[#0D1320]/80 p-5 backdrop-blur-xl shadow-xl">
              <div className="flex items-center space-x-2 text-white text-xs font-semibold uppercase tracking-wider mb-3 pb-2 border-b border-white/10">
                <TrendingUp className="h-4 w-4 text-cyan-400" />
                <span>Cash Flow & Spending Observations</span>
              </div>
              <ul className="space-y-2 text-xs text-slate-300">
                {advisoryResult.spendingObservations.map((item, idx) => (
                  <li key={idx} className="flex items-start space-x-2">
                    <span className="text-cyan-400 font-bold">•</span>
                    <span className="leading-relaxed">{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* 2. Debt Management Suggestions */}
            <div className="rounded-2xl border border-white/10 bg-[#0D1320]/80 p-5 backdrop-blur-xl shadow-xl">
              <div className="flex items-center space-x-2 text-white text-xs font-semibold uppercase tracking-wider mb-3 pb-2 border-b border-white/10">
                <ShieldCheck className="h-4 w-4 text-indigo-400" />
                <span>Debt Optimization & EMI Mitigation</span>
              </div>
              <ul className="space-y-2 text-xs text-slate-300">
                {advisoryResult.debtManagementAdvice.map((item, idx) => (
                  <li key={idx} className="flex items-start space-x-2">
                    <span className="text-indigo-400 font-bold">•</span>
                    <span className="leading-relaxed">{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* 3. Credit Score Improvement Roadmap */}
            <div className="rounded-2xl border border-white/10 bg-[#0D1320]/80 p-5 backdrop-blur-xl shadow-xl">
              <div className="flex items-center space-x-2 text-white text-xs font-semibold uppercase tracking-wider mb-3 pb-2 border-b border-white/10">
                <FileCheck className="h-4 w-4 text-emerald-400" />
                <span>Credit Score Improvement Checklist</span>
              </div>
              <ul className="space-y-2 text-xs text-slate-300">
                {advisoryResult.creditImprovementChecklist.map((item, idx) => (
                  <li key={idx} className="flex items-start space-x-2">
                    <span className="text-emerald-400 font-bold">•</span>
                    <span className="leading-relaxed">{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* 4. Savings & Buffer Strategy */}
            <div className="rounded-2xl border border-white/10 bg-[#0D1320]/80 p-5 backdrop-blur-xl shadow-xl">
              <div className="flex items-center space-x-2 text-white text-xs font-semibold uppercase tracking-wider mb-3 pb-2 border-b border-white/10">
                <PiggyBank className="h-4 w-4 text-amber-400" />
                <span>Emergency Buffer & Savings Strategy</span>
              </div>
              <ul className="space-y-2 text-xs text-slate-300">
                {advisoryResult.savingsStrategies.map((item, idx) => (
                  <li key={idx} className="flex items-start space-x-2">
                    <span className="text-amber-400 font-bold">•</span>
                    <span className="leading-relaxed">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* EMI Affordability Guidance & Loan Readiness */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="rounded-2xl border border-white/10 bg-[#0D1320]/80 p-5 backdrop-blur-xl">
              <h4 className="text-xs font-semibold text-white uppercase tracking-wider mb-2">
                EMI Affordability Guidance
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed">
                {advisoryResult.emiAffordabilityGuidance}
              </p>
            </div>

            <div className="rounded-2xl border border-white/10 bg-[#0D1320]/80 p-5 backdrop-blur-xl">
              <h4 className="text-xs font-semibold text-white uppercase tracking-wider mb-2">
                Loan Readiness Assessment
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed">
                {advisoryResult.loanReadinessAssessment}
              </p>
            </div>
          </div>

          {/* Priority Action Plan (Immediate, Medium Term, Long Term) */}
          {advisoryResult.actionPlan && (
            <div className="rounded-2xl border border-white/10 bg-[#0D1320]/80 p-6 backdrop-blur-xl shadow-xl">
              <h4 className="text-xs font-semibold text-white uppercase tracking-wider mb-4 pb-2 border-b border-white/10">
                Chronological Action Plan
              </h4>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                {/* Immediate */}
                <div className="rounded-xl border border-cyan-500/20 bg-cyan-500/5 p-4">
                  <span className="font-bold text-cyan-300 block mb-2">
                    Phase 1: Immediate (30 Days)
                  </span>
                  <ul className="space-y-1.5 text-slate-300">
                    {advisoryResult.actionPlan.immediate?.map((act, i) => (
                      <li key={i} className="flex items-start space-x-1.5">
                        <span className="text-cyan-400 font-bold">•</span>
                        <span>{act}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Medium Term */}
                <div className="rounded-xl border border-indigo-500/20 bg-indigo-500/5 p-4">
                  <span className="font-bold text-indigo-300 block mb-2">
                    Phase 2: Medium-Term (3-6 Months)
                  </span>
                  <ul className="space-y-1.5 text-slate-300">
                    {advisoryResult.actionPlan.mediumTerm?.map((act, i) => (
                      <li key={i} className="flex items-start space-x-1.5">
                        <span className="text-indigo-400 font-bold">•</span>
                        <span>{act}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Long Term */}
                <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/5 p-4">
                  <span className="font-bold text-emerald-300 block mb-2">
                    Phase 3: Long-Term (6-12 Months)
                  </span>
                  <ul className="space-y-1.5 text-slate-300">
                    {advisoryResult.actionPlan.longTerm?.map((act, i) => (
                      <li key={i} className="flex items-start space-x-1.5">
                        <span className="text-emerald-400 font-bold">•</span>
                        <span>{act}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          )}

          {/* Regulatory Safety Disclaimer */}
          <div className="rounded-xl border border-white/5 bg-white/[0.02] p-4 text-xs text-slate-400 flex items-start space-x-3">
            <Info className="h-5 w-5 text-indigo-400 flex-shrink-0 mt-0.5" />
            <div className="space-y-1">
              <strong className="text-slate-200">Regulatory Advisory Disclaimer:</strong>
              <p className="leading-relaxed">{advisoryResult.disclaimer}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
