import React, { useState } from 'react';
import {
  CreditCard,
  CheckCircle2,
  AlertTriangle,
  HelpCircle,
  TrendingUp,
  ShieldCheck,
  Zap,
  Info,
  ArrowRight,
} from 'lucide-react';
import { CreditAnalysisResult, Currency } from '../types';
import { analyzeCreditScore } from '../utils/calculations';
import { formatCurrency } from '../utils/formatters';

interface CreditAnalyzerViewProps {
  initialScore?: number;
  currency: Currency;
  onUpdateScore: (score: number) => void;
  onNavigateToLoan: () => void;
}

export const CreditAnalyzerView: React.FC<CreditAnalyzerViewProps> = ({
  initialScore = 750,
  currency,
  onUpdateScore,
  onNavigateToLoan,
}) => {
  const [score, setScore] = useState<number>(initialScore);
  const [paymentHistory, setPaymentHistory] = useState<number>(98);
  const [utilization, setUtilization] = useState<number>(22);
  const [accounts, setAccounts] = useState<number>(6);
  const [historyAge, setHistoryAge] = useState<number>(5);
  const [inquiries, setInquiries] = useState<number>(1);
  const [outstandingDebt, setOutstandingDebt] = useState<number>(14000);

  const analysis: CreditAnalysisResult = analyzeCreditScore({
    score,
    paymentHistoryPercent: paymentHistory,
    creditUtilizationPercent: utilization,
    creditAccountsCount: accounts,
    creditAgeYears: historyAge,
    recentHardInquiries: inquiries,
    outstandingDebt,
  });

  const handleScoreChange = (newScore: number) => {
    const clamped = Math.max(300, Math.min(850, newScore));
    setScore(clamped);
    onUpdateScore(clamped);
  };

  // Semi-circle gauge calculation
  // Total span 300 to 850 = 550
  const percentageOfRange = Math.max(0, Math.min(1, (score - 300) / 550));
  // Needle rotation from -90deg to +90deg (180deg total sweep)
  const needleRotation = -90 + percentageOfRange * 180;

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Header */}
      <div className="border-b border-white/10 pb-4">
        <div className="flex items-center space-x-2">
          <CreditCard className="h-6 w-6 text-cyan-400" />
          <h2 className="text-2xl font-bold tracking-tight text-white">
            Credit Health & Factor Diagnostic Analyzer
          </h2>
        </div>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          Educational evaluation of credit tiers, revolving credit utilization, inquiry velocity,
          and tailored score optimization strategies.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Credit Score Meter & Tier Bands */}
        <div className="lg:col-span-6 space-y-6">
          <div className="rounded-2xl border border-white/10 bg-[#0D1320]/80 p-6 backdrop-blur-xl shadow-xl flex flex-col items-center text-center relative overflow-hidden">
            {/* Top Score Readout */}
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Educational Credit Bureau Index
            </span>

            {/* Semi-circular Speedometer SVG */}
            <div className="relative w-72 h-44 mt-4 flex items-end justify-center">
              <svg viewBox="0 0 200 110" className="w-full h-full">
                {/* Arc segments for 5 tiers */}
                {/* Poor (300-579): 0 to 36 deg */}
                <path
                  d="M 20 100 A 80 80 0 0 1 40 43"
                  fill="none"
                  stroke="#EF4444"
                  strokeWidth="16"
                  strokeLinecap="round"
                />
                {/* Fair (580-669): 36 to 72 deg */}
                <path
                  d="M 43 40 A 80 80 0 0 1 82 23"
                  fill="none"
                  stroke="#F59E0B"
                  strokeWidth="16"
                />
                {/* Good (670-739): 72 to 108 deg */}
                <path
                  d="M 85 22 A 80 80 0 0 1 125 24"
                  fill="none"
                  stroke="#6366F1"
                  strokeWidth="16"
                />
                {/* Very Good (740-799): 108 to 144 deg */}
                <path
                  d="M 128 25 A 80 80 0 0 1 163 45"
                  fill="none"
                  stroke="#06B6D4"
                  strokeWidth="16"
                />
                {/* Excellent (800-850): 144 to 180 deg */}
                <path
                  d="M 165 48 A 80 80 0 0 1 180 100"
                  fill="none"
                  stroke="#22C55E"
                  strokeWidth="16"
                  strokeLinecap="round"
                />

                {/* Center Pivot & Needle */}
                <g transform={`translate(100, 100) rotate(${needleRotation})`}>
                  <line
                    x1="0"
                    y1="0"
                    x2="0"
                    y2="-68"
                    stroke="#F8FAFC"
                    strokeWidth="3"
                    strokeLinecap="round"
                  />
                  <circle cx="0" cy="0" r="6" fill="#6366F1" />
                </g>
              </svg>

              {/* Score text overlay */}
              <div className="absolute bottom-2 flex flex-col items-center">
                <span className="text-4xl font-extrabold text-white tracking-tight">{score}</span>
                <span
                  style={{ color: analysis.tierColor }}
                  className="text-xs font-bold uppercase tracking-wider mt-0.5"
                >
                  {analysis.tier} Tier
                </span>
              </div>
            </div>

            {/* Score Slider */}
            <div className="w-full mt-4 space-y-2">
              <input
                id="credit-score-slider"
                type="range"
                min={300}
                max={850}
                step={1}
                value={score}
                onChange={(e) => handleScoreChange(Number(e.target.value))}
                className="w-full h-2.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
              />
              <div className="flex justify-between text-[11px] text-slate-400 font-medium">
                <span>300 (Min)</span>
                <span>580</span>
                <span>670</span>
                <span>740</span>
                <span>850 (Max)</span>
              </div>
            </div>

            {/* 5 Tier Bands Reference Cards */}
            <div className="grid grid-cols-5 gap-1.5 w-full mt-6 text-center text-[10px]">
              <div
                className={`p-1.5 rounded-lg border ${
                  analysis.tier === 'Poor'
                    ? 'border-rose-500 bg-rose-500/20 font-bold text-white'
                    : 'border-white/5 bg-white/[0.02] text-slate-400'
                }`}
              >
                <span className="block text-rose-400 font-semibold">Poor</span>
                <span>300-579</span>
              </div>
              <div
                className={`p-1.5 rounded-lg border ${
                  analysis.tier === 'Fair'
                    ? 'border-amber-500 bg-amber-500/20 font-bold text-white'
                    : 'border-white/5 bg-white/[0.02] text-slate-400'
                }`}
              >
                <span className="block text-amber-400 font-semibold">Fair</span>
                <span>580-669</span>
              </div>
              <div
                className={`p-1.5 rounded-lg border ${
                  analysis.tier === 'Good'
                    ? 'border-indigo-500 bg-indigo-500/20 font-bold text-white'
                    : 'border-white/5 bg-white/[0.02] text-slate-400'
                }`}
              >
                <span className="block text-indigo-400 font-semibold">Good</span>
                <span>670-739</span>
              </div>
              <div
                className={`p-1.5 rounded-lg border ${
                  analysis.tier === 'Very Good'
                    ? 'border-cyan-500 bg-cyan-500/20 font-bold text-white'
                    : 'border-white/5 bg-white/[0.02] text-slate-400'
                }`}
              >
                <span className="block text-cyan-300 font-semibold">Very Good</span>
                <span>740-799</span>
              </div>
              <div
                className={`p-1.5 rounded-lg border ${
                  analysis.tier === 'Excellent'
                    ? 'border-emerald-500 bg-emerald-500/20 font-bold text-white'
                    : 'border-white/5 bg-white/[0.02] text-slate-400'
                }`}
              >
                <span className="block text-emerald-400 font-semibold">Excellent</span>
                <span>800-850</span>
              </div>
            </div>

            {/* Health Summary Statement */}
            <p className="mt-5 text-xs text-slate-300 bg-white/5 p-3 rounded-xl border border-white/10 text-left leading-relaxed">
              {analysis.healthSummary}
            </p>
          </div>

          {/* Quick Action to Eligibility */}
          <div className="rounded-2xl border border-white/10 bg-[#0D1320]/80 p-5 backdrop-blur-xl flex items-center justify-between">
            <div>
              <h4 className="text-xs font-semibold text-white">
                How does {score} affect loan sanctions?
              </h4>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Test your score with active income in the underwriting engine.
              </p>
            </div>
            <button
              onClick={onNavigateToLoan}
              className="rounded-xl bg-indigo-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-indigo-500 transition flex items-center space-x-1"
            >
              <span>Test Loan Impact</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>

        {/* Right Column: Diagnostic Factors & Actions */}
        <div className="lg:col-span-6 space-y-6">
          {/* Factor Controls & Health Indicators */}
          <div className="rounded-2xl border border-white/10 bg-[#0D1320]/80 p-6 backdrop-blur-xl shadow-xl space-y-4">
            <h3 className="text-xs font-semibold text-white uppercase tracking-wider border-b border-white/10 pb-3">
              Key Scoring Factor Metrics
            </h3>

            {/* 1. Payment History (35%) */}
            <div className="rounded-xl border border-white/5 bg-white/[0.02] p-3 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-white">Payment History (35% Weight)</span>
                <span className="font-bold text-cyan-300">{paymentHistory}%</span>
              </div>
              <input
                type="range"
                min={70}
                max={100}
                step={1}
                value={paymentHistory}
                onChange={(e) => setPaymentHistory(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
              />
              <div className="flex justify-between text-[10px] text-slate-400">
                <span>Status: {analysis.metrics.paymentHistory.status}</span>
                <span>Target: 100% on-time</span>
              </div>
            </div>

            {/* 2. Credit Utilization (30%) */}
            <div className="rounded-xl border border-white/5 bg-white/[0.02] p-3 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-white">Credit Card Utilization (30% Weight)</span>
                <span className={`font-bold ${utilization <= 30 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {utilization}%
                </span>
              </div>
              <input
                type="range"
                min={0}
                max={100}
                step={1}
                value={utilization}
                onChange={(e) => setUtilization(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
              />
              <div className="flex justify-between text-[10px] text-slate-400">
                <span>Status: {analysis.metrics.utilization.status}</span>
                <span>Rule of thumb: Maintain &lt;30%</span>
              </div>
            </div>

            {/* 3. Credit Age & Inquiries */}
            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-xl border border-white/5 bg-white/[0.02] p-3 text-xs">
                <label className="text-slate-300 font-medium block mb-1">
                  Credit Age ({historyAge} yrs)
                </label>
                <input
                  type="range"
                  min={1}
                  max={25}
                  value={historyAge}
                  onChange={(e) => setHistoryAge(Number(e.target.value))}
                  className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                />
                <span className="text-[10px] text-slate-500 mt-1 block">
                  15% Weight (History length)
                </span>
              </div>

              <div className="rounded-xl border border-white/5 bg-white/[0.02] p-3 text-xs">
                <label className="text-slate-300 font-medium block mb-1">
                  Recent Inquiries ({inquiries})
                </label>
                <input
                  type="range"
                  min={0}
                  max={10}
                  value={inquiries}
                  onChange={(e) => setInquiries(Number(e.target.value))}
                  className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                />
                <span className="text-[10px] text-slate-500 mt-1 block">
                  10% Weight (Credit hunger)
                </span>
              </div>
            </div>
          </div>

          {/* Risk Factors & Improvement Suggestions */}
          <div className="space-y-4">
            <div className="rounded-2xl border border-amber-500/20 bg-amber-500/5 p-4">
              <div className="flex items-center space-x-2 text-amber-400 text-xs font-semibold uppercase tracking-wider mb-2">
                <AlertTriangle className="h-4 w-4" />
                <span>Identified Credit Headwinds</span>
              </div>
              <ul className="space-y-1.5 text-xs text-slate-300">
                {analysis.riskFactors.map((rf, idx) => (
                  <li key={idx} className="flex items-start space-x-1.5">
                    <span className="text-amber-400 font-bold">•</span>
                    <span>{rf}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="rounded-2xl border border-emerald-500/20 bg-emerald-500/5 p-4">
              <div className="flex items-center space-x-2 text-emerald-400 text-xs font-semibold uppercase tracking-wider mb-2">
                <Zap className="h-4 w-4" />
                <span>Actionable Score Uplift Strategies</span>
              </div>
              <ul className="space-y-1.5 text-xs text-slate-300">
                {analysis.improvementSuggestions.map((sug, idx) => (
                  <li key={idx} className="flex items-start space-x-1.5">
                    <span className="text-emerald-400 font-bold">•</span>
                    <span>{sug}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Educational Bureau Disclaimer */}
          <div className="rounded-xl border border-white/5 bg-white/[0.02] p-3 text-[11px] text-slate-400 flex items-start space-x-2">
            <Info className="h-4 w-4 text-slate-500 flex-shrink-0 mt-0.5" />
            <p>
              <strong>Educational Bureau Notice:</strong> Credit scores vary across bureaus (Equifax,
              Experian, TransUnion, CIBIL). This module provides algorithmic estimations to help you
              understand weighting levers and does not replace official credit reports.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
