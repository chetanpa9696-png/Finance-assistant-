import React, { useState } from 'react';
import {
  ShieldCheck,
  TrendingUp,
  CreditCard,
  Calculator,
  Sparkles,
  Database,
  Menu,
  X,
  FileText,
  Lock,
  RefreshCw,
} from 'lucide-react';
import { Currency } from '../types';

export type NavTab = 'dashboard' | 'loan' | 'credit' | 'emi' | 'ai-tips' | 'records';

interface HeaderProps {
  activeTab: NavTab;
  onTabChange: (tab: NavTab) => void;
  currency: Currency;
  onCurrencyChange: (c: Currency) => void;
  onOpenPrivacy: () => void;
  onOpenMethodology: () => void;
  recordsCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onTabChange,
  currency,
  onCurrencyChange,
  onOpenPrivacy,
  onOpenMethodology,
  recordsCount,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: TrendingUp },
    { id: 'loan', label: 'Loan Eligibility', icon: ShieldCheck },
    { id: 'credit', label: 'Credit Analyzer', icon: CreditCard },
    { id: 'emi', label: 'EMI Calculator', icon: Calculator },
    { id: 'ai-tips', label: 'AI Financial Tips', icon: Sparkles, badge: 'AI' },
    {
      id: 'records',
      label: 'Financial Records',
      icon: Database,
      count: recordsCount,
    },
  ];

  const handleNavClick = (tabId: NavTab) => {
    onTabChange(tabId);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b border-white/10 bg-[#070B14]/85 backdrop-blur-md transition-all">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Brand & Logo */}
        <div
          id="brand-header-logo"
          onClick={() => handleNavClick('dashboard')}
          className="flex cursor-pointer items-center space-x-3 group"
        >
          <div className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-tr from-indigo-600 to-cyan-400 p-0.5 shadow-lg shadow-indigo-500/20 group-hover:shadow-indigo-500/40 transition">
            <div className="flex h-full w-full items-center justify-center rounded-[10px] bg-[#070B14]">
              <Sparkles className="h-5 w-5 text-cyan-400 animate-pulse" />
            </div>
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-bold text-lg tracking-tight text-white group-hover:text-indigo-300 transition">
                FinDecision<span className="text-cyan-400">.AI</span>
              </span>
              <span className="rounded border border-indigo-500/40 bg-indigo-500/10 px-1.5 py-0.5 text-[10px] font-semibold text-indigo-300 tracking-wider">
                BFSI
              </span>
            </div>
            <p className="text-[11px] text-slate-400 hidden sm:block">
              Intelligent Credit & Loan Advisory Engine
            </p>
          </div>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center space-x-1" aria-label="Main Navigation">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                id={`nav-btn-${item.id}`}
                onClick={() => handleNavClick(item.id as NavTab)}
                className={`relative flex items-center space-x-2 px-3.5 py-2 rounded-lg text-sm font-medium transition-all ${
                  isActive
                    ? 'bg-white/10 text-white shadow-inner border border-white/15'
                    : 'text-slate-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <Icon className={`h-4 w-4 ${isActive ? 'text-cyan-400' : 'text-slate-400'}`} />
                <span>{item.label}</span>
                {item.badge && (
                  <span className="rounded-full bg-gradient-to-r from-indigo-500 to-cyan-500 px-1.5 py-0.2 text-[9px] font-extrabold text-white">
                    {item.badge}
                  </span>
                )}
                {typeof item.count === 'number' && item.count > 0 && (
                  <span className="rounded-full bg-slate-800 border border-slate-700 px-1.5 py-0.2 text-[10px] font-bold text-slate-300">
                    {item.count}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Controls: Currency & Modals & Mobile Toggle */}
        <div className="flex items-center space-x-2 sm:space-x-3">
          {/* Currency Switcher */}
          <div className="flex items-center rounded-lg border border-white/10 bg-white/5 p-0.5">
            {(['USD', 'INR', 'EUR', 'GBP'] as Currency[]).map((curr) => (
              <button
                key={curr}
                id={`currency-select-${curr}`}
                onClick={() => onCurrencyChange(curr)}
                className={`px-2 py-1 text-xs font-semibold rounded-md transition ${
                  currency === curr
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
                title={`Set display currency to ${curr}`}
              >
                {curr === 'USD' ? '$' : curr === 'INR' ? '₹' : curr === 'EUR' ? '€' : '£'}
              </button>
            ))}
          </div>

          {/* Methodology & Privacy triggers */}
          <button
            id="methodology-modal-trigger"
            onClick={onOpenMethodology}
            title="Underwriting & Calculation Methodology"
            className="hidden sm:flex items-center space-x-1 rounded-lg border border-white/10 bg-white/5 px-2.5 py-1.5 text-xs text-slate-300 hover:bg-white/10 transition"
          >
            <FileText className="h-3.5 w-3.5 text-indigo-400" />
            <span className="hidden md:inline">Methodology</span>
          </button>

          <button
            id="privacy-modal-trigger"
            onClick={onOpenPrivacy}
            title="Privacy Notice & Data Protection"
            className="hidden sm:flex items-center space-x-1 rounded-lg border border-white/10 bg-white/5 px-2.5 py-1.5 text-xs text-slate-300 hover:bg-white/10 transition"
          >
            <Lock className="h-3.5 w-3.5 text-emerald-400" />
            <span className="hidden md:inline">Privacy</span>
          </button>

          {/* Mobile menu toggle */}
          <button
            id="mobile-menu-toggle-btn"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden rounded-lg border border-white/10 bg-white/5 p-2 text-slate-300 hover:bg-white/10"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-b border-white/10 bg-[#070B14] px-4 pt-2 pb-5 space-y-1 animate-fadeIn">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id as NavTab)}
                className={`flex w-full items-center justify-between px-3 py-2.5 rounded-lg text-sm font-medium transition ${
                  isActive
                    ? 'bg-indigo-600/20 text-white border border-indigo-500/30'
                    : 'text-slate-300 hover:bg-white/5'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <Icon className={`h-4 w-4 ${isActive ? 'text-cyan-400' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </div>
                {item.badge && (
                  <span className="rounded-full bg-indigo-500/20 border border-indigo-500/40 px-2 py-0.5 text-[10px] text-indigo-300">
                    {item.badge}
                  </span>
                )}
                {typeof item.count === 'number' && item.count > 0 && (
                  <span className="rounded-full bg-slate-800 px-2 py-0.5 text-[10px] text-slate-300">
                    {item.count} records
                  </span>
                )}
              </button>
            );
          })}

          <div className="pt-3 flex items-center justify-between border-t border-white/10 text-xs text-slate-400">
            <button onClick={onOpenMethodology} className="flex items-center space-x-1.5 py-1">
              <FileText className="h-3.5 w-3.5 text-indigo-400" />
              <span>Calculation Logic</span>
            </button>
            <button onClick={onOpenPrivacy} className="flex items-center space-x-1.5 py-1">
              <Lock className="h-3.5 w-3.5 text-emerald-400" />
              <span>Privacy-by-Design</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
