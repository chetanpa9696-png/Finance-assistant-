import React, { useState, useMemo } from 'react';
import {
  Calculator,
  PieChart,
  Calendar,
  Layers,
  ArrowDownRight,
  TrendingDown,
  Info,
  DollarSign,
  Percent,
} from 'lucide-react';
import { Currency, EMICalculationResult } from '../types';
import { formatCurrency, formatPercent } from '../utils/formatters';
import { calculateEMI } from '../utils/calculations';

interface EMICalculatorViewProps {
  initialPrincipal?: number;
  initialTenureMonths?: number;
  currency: Currency;
}

export const EMICalculatorView: React.FC<EMICalculatorViewProps> = ({
  initialPrincipal = 250000,
  initialTenureMonths = 240,
  currency,
}) => {
  const [principal, setPrincipal] = useState<number>(initialPrincipal);
  const [interestRate, setInterestRate] = useState<number>(8.5);
  const [tenureValue, setTenureValue] = useState<number>(Math.round(initialTenureMonths / 12));
  const [tenureUnit, setTenureUnit] = useState<'years' | 'months'>('years');
  const [scheduleView, setScheduleView] = useState<'yearly' | 'monthly'>('yearly');

  const tenureInMonths = useMemo(() => {
    return tenureUnit === 'years' ? tenureValue * 12 : tenureValue;
  }, [tenureValue, tenureUnit]);

  const result: EMICalculationResult = useMemo(() => {
    return calculateEMI(principal, interestRate, tenureInMonths);
  }, [principal, interestRate, tenureInMonths]);

  // Donut chart calculations
  const circumference = 2 * Math.PI * 40; // radius = 40
  const principalStroke = (result.principalPercentage / 100) * circumference;
  const interestStroke = (result.interestPercentage / 100) * circumference;

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Module Header */}
      <div className="border-b border-white/10 pb-4">
        <div className="flex items-center space-x-2">
          <Calculator className="h-6 w-6 text-emerald-400" />
          <h2 className="text-2xl font-bold tracking-tight text-white">
            Real-Time EMI & Amortization Calculator
          </h2>
        </div>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          Compute precise monthly installments, interest distributions, and amortization schedules
          with instant zero-interest handling.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Interactive Sliders & Inputs */}
        <div className="lg:col-span-6 space-y-6">
          <div className="rounded-2xl border border-white/10 bg-[#0D1320]/80 p-6 backdrop-blur-xl shadow-xl space-y-6">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-white border-b border-white/10 pb-3">
              Loan Specification Parameters
            </h3>

            {/* 1. Principal Loan Amount */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label htmlFor="principal-input" className="text-xs font-medium text-slate-300">
                  Loan Principal Amount
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2 text-xs text-slate-400 font-semibold">
                    {currency === 'INR' ? '₹' : '$'}
                  </span>
                  <input
                    id="principal-input"
                    type="number"
                    min={1000}
                    max={5000000}
                    step={5000}
                    value={principal || ''}
                    onChange={(e) => setPrincipal(Math.max(0, Number(e.target.value)))}
                    className="w-40 rounded-xl border border-white/15 bg-white/5 pl-7 pr-3 py-1.5 text-sm font-bold text-white text-right focus:outline-none focus:ring-2 focus:ring-emerald-500 transition"
                  />
                </div>
              </div>
              <input
                id="principal-slider"
                type="range"
                min={5000}
                max={1000000}
                step={5000}
                value={principal}
                onChange={(e) => setPrincipal(Number(e.target.value))}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-400"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-medium">
                <span>{formatCurrency(5000, currency)}</span>
                <span>{formatCurrency(500000, currency)}</span>
                <span>{formatCurrency(1000000, currency)}</span>
              </div>
            </div>

            {/* 2. Annual Interest Rate */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-1.5">
                  <label htmlFor="interest-input" className="text-xs font-medium text-slate-300">
                    Annual Interest Rate (% p.a.)
                  </label>
                  {interestRate === 0 && (
                    <span className="rounded bg-emerald-500/20 px-1.5 py-0.5 text-[10px] text-emerald-300 font-semibold">
                      0% Interest Loan
                    </span>
                  )}
                </div>
                <div className="relative">
                  <input
                    id="interest-input"
                    type="number"
                    min={0}
                    max={35}
                    step={0.1}
                    value={interestRate}
                    onChange={(e) => setInterestRate(Math.max(0, Number(e.target.value)))}
                    className="w-28 rounded-xl border border-white/15 bg-white/5 pl-3 pr-7 py-1.5 text-sm font-bold text-white text-right focus:outline-none focus:ring-2 focus:ring-emerald-500 transition"
                  />
                  <span className="absolute right-3 top-2 text-xs text-slate-400 font-semibold">
                    %
                  </span>
                </div>
              </div>
              <input
                id="interest-slider"
                type="range"
                min={0}
                max={25}
                step={0.1}
                value={interestRate}
                onChange={(e) => setInterestRate(Number(e.target.value))}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-400"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-medium">
                <span>0% (Promo)</span>
                <span>8.5% (Prime)</span>
                <span>15% (Personal)</span>
                <span>25%</span>
              </div>
            </div>

            {/* 3. Loan Tenure with Years/Months toggle */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label htmlFor="tenure-input" className="text-xs font-medium text-slate-300">
                  Loan Tenure
                </label>
                <div className="flex items-center space-x-2">
                  <input
                    id="tenure-input"
                    type="number"
                    min={1}
                    max={tenureUnit === 'years' ? 40 : 480}
                    value={tenureValue}
                    onChange={(e) => setTenureValue(Math.max(1, Number(e.target.value)))}
                    className="w-24 rounded-xl border border-white/15 bg-white/5 px-3 py-1.5 text-sm font-bold text-white text-right focus:outline-none focus:ring-2 focus:ring-emerald-500 transition"
                  />
                  <div className="flex rounded-lg border border-white/10 bg-white/5 p-0.5 text-xs font-medium">
                    <button
                      type="button"
                      id="tenure-unit-years-btn"
                      onClick={() => {
                        if (tenureUnit !== 'years') {
                          setTenureUnit('years');
                          setTenureValue(Math.max(1, Math.round(tenureValue / 12)));
                        }
                      }}
                      className={`px-2.5 py-1 rounded-md transition ${
                        tenureUnit === 'years'
                          ? 'bg-emerald-500 text-slate-950 font-bold'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      Years
                    </button>
                    <button
                      type="button"
                      id="tenure-unit-months-btn"
                      onClick={() => {
                        if (tenureUnit !== 'months') {
                          setTenureUnit('months');
                          setTenureValue(tenureValue * 12);
                        }
                      }}
                      className={`px-2.5 py-1 rounded-md transition ${
                        tenureUnit === 'months'
                          ? 'bg-emerald-500 text-slate-950 font-bold'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      Months
                    </button>
                  </div>
                </div>
              </div>
              <input
                id="tenure-slider"
                type="range"
                min={tenureUnit === 'years' ? 1 : 6}
                max={tenureUnit === 'years' ? 30 : 360}
                step={1}
                value={tenureValue}
                onChange={(e) => setTenureValue(Number(e.target.value))}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-400"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-medium">
                <span>{tenureUnit === 'years' ? '1 Year' : '6 Mos'}</span>
                <span>{tenureUnit === 'years' ? '15 Years' : '180 Mos'}</span>
                <span>{tenureUnit === 'years' ? '30 Years' : '360 Mos'}</span>
              </div>
            </div>

            {/* Quick Benchmark Presets */}
            <div className="pt-2 border-t border-white/10">
              <span className="text-[11px] text-slate-400 block mb-2 font-medium">
                Quick Benchmarks:
              </span>
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setPrincipal(350000);
                    setInterestRate(7.25);
                    setTenureUnit('years');
                    setTenureValue(30);
                  }}
                  className="rounded-lg border border-white/10 bg-white/5 px-2.5 py-1 text-xs text-slate-300 hover:bg-white/10 transition"
                >
                  30-Yr Home Loan (7.25%)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setPrincipal(45000);
                    setInterestRate(6.5);
                    setTenureUnit('years');
                    setTenureValue(5);
                  }}
                  className="rounded-lg border border-white/10 bg-white/5 px-2.5 py-1 text-xs text-slate-300 hover:bg-white/10 transition"
                >
                  5-Yr Auto Loan (6.5%)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setPrincipal(15000);
                    setInterestRate(11.9);
                    setTenureUnit('years');
                    setTenureValue(3);
                  }}
                  className="rounded-lg border border-white/10 bg-white/5 px-2.5 py-1 text-xs text-slate-300 hover:bg-white/10 transition"
                >
                  3-Yr Personal Loan (11.9%)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setPrincipal(20000);
                    setInterestRate(0);
                    setTenureUnit('months');
                    setTenureValue(12);
                  }}
                  className="rounded-lg border border-emerald-500/30 bg-emerald-500/10 px-2.5 py-1 text-xs text-emerald-300 hover:bg-emerald-500/20 transition"
                >
                  12-Mo 0% Retail EMI
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Dynamic EMI Results & Donut Chart */}
        <div className="lg:col-span-6 space-y-6">
          {/* Main EMI Highlight Card */}
          <div className="rounded-2xl border border-white/10 bg-[#0D1320]/80 p-6 backdrop-blur-xl shadow-xl">
            <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider">
              Calculated Monthly Payment
            </span>
            <div className="flex items-baseline space-x-3 mt-1">
              <span className="text-3xl sm:text-4xl font-extrabold text-emerald-400 tracking-tight">
                {formatCurrency(result.monthlyEMI, currency)}
              </span>
              <span className="text-xs text-slate-400 font-medium">/ month</span>
            </div>

            {/* Donut Chart & Ratio Breakdown */}
            <div className="mt-6 pt-5 border-t border-white/10 grid grid-cols-1 sm:grid-cols-12 gap-6 items-center">
              {/* Donut SVG */}
              <div className="sm:col-span-5 flex justify-center">
                <div className="relative w-36 h-36">
                  <svg viewBox="0 0 100 100" className="w-full h-full transform -rotate-90">
                    {/* Background track */}
                    <circle
                      cx="50"
                      cy="50"
                      r="40"
                      fill="transparent"
                      stroke="#1e293b"
                      strokeWidth="12"
                    />
                    {/* Principal circle (Cyan) */}
                    <circle
                      cx="50"
                      cy="50"
                      r="40"
                      fill="transparent"
                      stroke="#06B6D4"
                      strokeWidth="12"
                      strokeDasharray={`${principalStroke} ${circumference}`}
                      strokeDashoffset="0"
                      strokeLinecap="round"
                    />
                    {/* Interest circle (Amber) */}
                    <circle
                      cx="50"
                      cy="50"
                      r="40"
                      fill="transparent"
                      stroke="#F59E0B"
                      strokeWidth="12"
                      strokeDasharray={`${interestStroke} ${circumference}`}
                      strokeDashoffset={-principalStroke}
                      strokeLinecap="round"
                    />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                    <span className="text-[10px] text-slate-400 uppercase font-semibold">Total</span>
                    <span className="text-xs font-bold text-white">
                      {formatCurrency(result.totalRepaymentAmount, currency)}
                    </span>
                  </div>
                </div>
              </div>

              {/* Legend & Details */}
              <div className="sm:col-span-7 space-y-3 text-xs">
                <div className="rounded-xl border border-white/5 bg-white/[0.02] p-3 flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="h-3 w-3 rounded-full bg-cyan-400" />
                    <div>
                      <span className="font-semibold text-white">Principal Amount</span>
                      <p className="text-[10px] text-slate-400">{result.principalPercentage}% of total</p>
                    </div>
                  </div>
                  <span className="font-bold text-white">
                    {formatCurrency(result.principalAmount, currency)}
                  </span>
                </div>

                <div className="rounded-xl border border-white/5 bg-white/[0.02] p-3 flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="h-3 w-3 rounded-full bg-amber-400" />
                    <div>
                      <span className="font-semibold text-white">Total Interest</span>
                      <p className="text-[10px] text-slate-400">{result.interestPercentage}% of total</p>
                    </div>
                  </div>
                  <span className="font-bold text-amber-400">
                    {formatCurrency(result.totalInterestPayable, currency)}
                  </span>
                </div>

                <div className="pt-2 flex justify-between text-[11px] text-slate-400">
                  <span>Tenure Duration:</span>
                  <span className="font-semibold text-slate-200">
                    {result.tenureMonths} Months ({(result.tenureMonths / 12).toFixed(1)} Yrs)
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Tip Card */}
          <div className="rounded-2xl border border-indigo-500/20 bg-indigo-500/5 p-4 text-xs text-slate-300 flex items-start space-x-3">
            <Info className="h-4 w-4 text-cyan-400 flex-shrink-0 mt-0.5" />
            <div>
              <strong className="text-white">Repayment Optimization Tip:</strong> Paying just an
              additional 5% towards principal monthly can significantly reduce total interest
              outflow and shorten loan tenure by several months.
            </div>
          </div>
        </div>
      </div>

      {/* Amortization Schedule Section */}
      <div className="rounded-2xl border border-white/10 bg-[#0D1320]/80 p-6 backdrop-blur-xl shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-white/10 gap-3">
          <div>
            <h3 className="text-base font-bold text-white flex items-center space-x-2">
              <Calendar className="h-4 w-4 text-cyan-400" />
              <span>Loan Amortization Repayment Schedule</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Yearly and monthly breakdown of balance drawdown and principal accumulation
            </p>
          </div>

          <div className="flex rounded-lg border border-white/10 bg-white/5 p-0.5 text-xs font-semibold">
            <button
              onClick={() => setScheduleView('yearly')}
              className={`px-3 py-1.5 rounded-md transition ${
                scheduleView === 'yearly'
                  ? 'bg-indigo-600 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Yearly Summary
            </button>
            <button
              onClick={() => setScheduleView('monthly')}
              className={`px-3 py-1.5 rounded-md transition ${
                scheduleView === 'monthly'
                  ? 'bg-indigo-600 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Sample Installments
            </button>
          </div>
        </div>

        {/* Table */}
        <div className="mt-4 overflow-x-auto">
          {scheduleView === 'yearly' ? (
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="border-b border-white/10 text-[11px] uppercase tracking-wider text-slate-400 bg-white/[0.02]">
                <tr>
                  <th className="py-2.5 px-3">Year</th>
                  <th className="py-2.5 px-3 text-right">Principal Repaid</th>
                  <th className="py-2.5 px-3 text-right">Interest Paid</th>
                  <th className="py-2.5 px-3 text-right">Total Yearly Outlay</th>
                  <th className="py-2.5 px-3 text-right">Remaining Balance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {result.yearlySchedule.map((row) => (
                  <tr key={row.year} className="hover:bg-white/[0.02] transition">
                    <td className="py-2.5 px-3 font-semibold text-white">Year {row.year}</td>
                    <td className="py-2.5 px-3 text-right text-cyan-300 font-medium">
                      {formatCurrency(row.principalPaid, currency)}
                    </td>
                    <td className="py-2.5 px-3 text-right text-amber-400 font-medium">
                      {formatCurrency(row.interestPaid, currency)}
                    </td>
                    <td className="py-2.5 px-3 text-right font-medium text-slate-200">
                      {formatCurrency(row.principalPaid + row.interestPaid, currency)}
                    </td>
                    <td className="py-2.5 px-3 text-right font-bold text-white">
                      {formatCurrency(row.remainingBalance, currency)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="border-b border-white/10 text-[11px] uppercase tracking-wider text-slate-400 bg-white/[0.02]">
                <tr>
                  <th className="py-2.5 px-3">Installment</th>
                  <th className="py-2.5 px-3 text-right">Opening Balance</th>
                  <th className="py-2.5 px-3 text-right">EMI</th>
                  <th className="py-2.5 px-3 text-right">Principal</th>
                  <th className="py-2.5 px-3 text-right">Interest</th>
                  <th className="py-2.5 px-3 text-right">Closing Balance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {result.monthlyScheduleSample.map((row) => (
                  <tr key={row.installmentNumber} className="hover:bg-white/[0.02] transition">
                    <td className="py-2.5 px-3 font-semibold text-white">{row.monthYear}</td>
                    <td className="py-2.5 px-3 text-right font-medium text-slate-400">
                      {formatCurrency(row.openingBalance, currency)}
                    </td>
                    <td className="py-2.5 px-3 text-right font-semibold text-emerald-400">
                      {formatCurrency(row.emi, currency)}
                    </td>
                    <td className="py-2.5 px-3 text-right text-cyan-300">
                      {formatCurrency(row.principalComponent, currency)}
                    </td>
                    <td className="py-2.5 px-3 text-right text-amber-400">
                      {formatCurrency(row.interestComponent, currency)}
                    </td>
                    <td className="py-2.5 px-3 text-right font-bold text-white">
                      {formatCurrency(row.closingBalance, currency)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
};
