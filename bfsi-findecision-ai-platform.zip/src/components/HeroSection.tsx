import React from 'react';
import {
  ShieldCheck,
  CreditCard,
  Calculator,
  Sparkles,
  ArrowRight,
  Info,
  CheckCircle2,
  Lock,
} from 'lucide-react';
import { NavTab } from './Header';
import { PRESET_PROFILES, ProfilePreset } from '../data/sampleProfiles';
import { FinancialProfile } from '../types';

interface HeroSectionProps {
  onNavigate: (tab: NavTab) => void;
  onApplyPreset: (profile: FinancialProfile) => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onNavigate, onApplyPreset }) => {
  return (
    <section className="relative overflow-hidden pt-8 pb-10 border-b border-white/10 bg-gradient-to-b from-[#0D1320]/60 via-[#070B14] to-[#070B14]">
      {/* Background glow accents */}
      <div
        className="pointer-events-none absolute -top-24 left-1/2 -translate-x-1/2 h-96 w-[700px] rounded-full bg-indigo-600/10 blur-3xl"
        aria-hidden="true"
      />
      <div
        className="pointer-events-none absolute top-12 right-10 h-72 w-72 rounded-full bg-cyan-500/10 blur-3xl"
        aria-hidden="true"
      />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Compliance Educational Pill */}
        <div className="mb-4 inline-flex items-center space-x-2 rounded-full border border-indigo-500/30 bg-indigo-500/10 px-3 py-1 text-xs text-indigo-300 backdrop-blur-md">
          <Sparkles className="h-3.5 w-3.5 text-cyan-400" />
          <span className="font-semibold">BFSI Decision Intelligence</span>
          <span className="text-white/40">|</span>
          <span className="text-slate-300 hidden sm:inline">
            Transparent Algorithms & AI-Grounded Scoring
          </span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Main Headline & CTAs */}
          <div className="lg:col-span-7 space-y-5">
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white leading-tight">
              Make Smarter Financial Decisions with{' '}
              <span className="bg-gradient-to-r from-indigo-400 via-cyan-300 to-emerald-400 bg-clip-text text-transparent">
                AI-Powered Insights
              </span>
            </h1>

            <p className="text-base sm:text-lg text-slate-300 max-w-2xl leading-relaxed">
              Evaluate retail loan eligibility, diagnose credit score factors, compute precise EMI
              schedules, and receive comprehensive financial recommendations.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-wrap gap-3 pt-2">
              <button
                id="hero-cta-loan"
                onClick={() => onNavigate('loan')}
                className="flex items-center space-x-2 rounded-xl bg-gradient-to-r from-indigo-600 to-cyan-600 px-5 py-3 text-sm font-semibold text-white shadow-lg shadow-indigo-600/25 hover:from-indigo-500 hover:to-cyan-500 transition active:scale-95"
              >
                <ShieldCheck className="h-4 w-4" />
                <span>Check Loan Eligibility</span>
                <ArrowRight className="h-4 w-4" />
              </button>

              <button
                id="hero-cta-credit"
                onClick={() => onNavigate('credit')}
                className="flex items-center space-x-2 rounded-xl border border-white/15 bg-white/5 px-4 py-3 text-sm font-medium text-slate-200 hover:bg-white/10 hover:text-white transition"
              >
                <CreditCard className="h-4 w-4 text-cyan-400" />
                <span>Credit Health Analyzer</span>
              </button>

              <button
                id="hero-cta-emi"
                onClick={() => onNavigate('emi')}
                className="flex items-center space-x-2 rounded-xl border border-white/15 bg-white/5 px-4 py-3 text-sm font-medium text-slate-200 hover:bg-white/10 hover:text-white transition"
              >
                <Calculator className="h-4 w-4 text-emerald-400" />
                <span>EMI Calculator</span>
              </button>

              <button
                id="hero-cta-ai"
                onClick={() => onNavigate('ai-tips')}
                className="flex items-center space-x-2 rounded-xl border border-indigo-500/40 bg-indigo-500/15 px-4 py-3 text-sm font-medium text-indigo-300 hover:bg-indigo-500/25 transition"
              >
                <Sparkles className="h-4 w-4 text-indigo-400" />
                <span>AI Advisor</span>
              </button>
            </div>

            {/* Trust & Safety Notice */}
            <div className="flex items-start space-x-2 pt-2 text-xs text-slate-400">
              <Info className="h-4 w-4 flex-shrink-0 text-cyan-400 mt-0.5" />
              <p>
                <strong className="text-slate-300">Regulatory Transparency Notice:</strong> All
                eligibility metrics and AI recommendations are educational decision-support
                estimates based on provided financial parameters and do not constitute formal credit
                bureau reports or institutional lender approvals.
              </p>
            </div>
          </div>

          {/* Quick Scenario Preset Loader */}
          <div className="lg:col-span-5">
            <div className="rounded-2xl border border-white/10 bg-[#0D1320]/80 p-5 backdrop-blur-xl shadow-2xl relative overflow-hidden">
              <div className="flex items-center justify-between pb-3 border-b border-white/10">
                <div className="flex items-center space-x-2">
                  <span className="flex h-2 w-2 rounded-full bg-emerald-400 animate-ping" />
                  <h3 className="text-xs font-semibold text-white tracking-wider uppercase">
                    One-Click Profile Scenarios
                  </h3>
                </div>
                <span className="text-[11px] text-slate-400">Instant Demo Data</span>
              </div>

              <p className="mt-3 text-xs text-slate-300">
                Load authentic test profiles to instantly explore eligibility scoring, EMI charts,
                and AI recommendations:
              </p>

              <div className="mt-4 space-y-2.5">
                {PRESET_PROFILES.map((preset: ProfilePreset) => (
                  <button
                    key={preset.id}
                    id={`load-preset-${preset.id}`}
                    onClick={() => onApplyPreset(preset.profile)}
                    className="w-full text-left rounded-xl border border-white/5 bg-white/[0.03] p-3 hover:bg-white/[0.08] hover:border-indigo-500/40 transition group flex items-center justify-between"
                  >
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="text-xs font-semibold text-white group-hover:text-cyan-300 transition">
                          {preset.name}
                        </span>
                        <span className="rounded bg-indigo-500/20 px-1.5 py-0.5 text-[10px] text-indigo-300 font-medium">
                          {preset.category}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
                        {preset.tagline}
                      </p>
                    </div>
                    <span className="text-[11px] font-medium text-cyan-400 opacity-0 group-hover:opacity-100 transition flex items-center space-x-1">
                      <span>Load</span>
                      <ArrowRight className="h-3 w-3" />
                    </span>
                  </button>
                ))}
              </div>

              <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between text-[11px] text-slate-400">
                <span className="flex items-center space-x-1">
                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                  <span>Configurable Underwriting</span>
                </span>
                <span className="flex items-center space-x-1">
                  <Lock className="h-3.5 w-3.5 text-indigo-400" />
                  <span>Client-Side Privacy</span>
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
