import React from 'react';
import {
  Wallet,
  Receipt,
  CreditCard,
  Scale,
  ShieldCheck,
  PiggyBank,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  ArrowUpRight,
  Sparkles,
  BookmarkPlus,
  RefreshCw,
} from 'lucide-react';
import { FinancialProfile, Currency, LoanEligibilityResult } from '../types';
import { formatCurrency, formatPercent, getStatusBadgeClasses, getRiskBadgeClasses } from '../utils/formatters';
import { NavTab } from './Header';
import { getCreditScoreTier } from '../utils/calculations';

interface DashboardViewProps {
  profile: FinancialProfile;
  eligibilityResult: LoanEligibilityResult;
  currency: Currency;
  onNavigate: (tab: NavTab) => void;
  onSaveRecord: () => void;
  isSavingRecord: boolean;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  profile,
  eligibilityResult,
  currency,
  onNavigate,
  onSaveRecord,
  isSavingRecord,
}) => {
  const { monthlyIncome, monthlyExpenses, existingEmi, creditScore, desiredLoanAmount } = profile;
  const {
    status,
    estimatedEligibleAmount,
    debtToIncomeRatio,
    disposableIncome,
    riskCategory,
    eligibilityScore,
  } = eligibilityResult;

  const statusStyle = getStatusBadgeClasses(status);
  const riskStyle = getRiskBadgeClasses(riskCategory);
  const creditTier = getCreditScoreTier(creditScore);

  // Financial distribution calculations
  const savings = Math.max(0, monthlyIncome - monthlyExpenses - existingEmi);
  const expensesPct = monthlyIncome > 0 ? (monthlyExpenses / monthlyIncome) * 100 : 0;
  const emiPct = monthlyIncome > 0 ? (existingEmi / monthlyIncome) * 100 : 0;
  const savingsPct = monthlyIncome > 0 ? (savings / monthlyIncome) * 100 : 0;

  // Maximum safe EMI threshold (50% rule)
  const maxSafeMonthlyEMI = Math.max(0, monthlyIncome * 0.5 - existingEmi);

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Top Welcome & Quick Actions Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-white/10 pb-5">
        <div>
          <div className="flex items-center space-x-3">
            <h2 className="text-2xl font-bold tracking-tight text-white">
              Financial Overview: {profile.fullName || 'Applicant Profile'}
            </h2>
            <span
              className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${statusStyle.bg} ${statusStyle.text} border ${statusStyle.border}`}
            >
              {status}
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Real-time multi-dimensional assessment of cash flows, creditworthiness, and borrowing
            capacity.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            id="save-record-dashboard-btn"
            onClick={onSaveRecord}
            disabled={isSavingRecord}
            className="flex items-center space-x-2 rounded-xl border border-white/15 bg-white/5 px-4 py-2 text-xs font-semibold text-slate-200 hover:bg-white/10 hover:text-white transition disabled:opacity-50"
          >
            {isSavingRecord ? (
              <RefreshCw className="h-4 w-4 animate-spin text-cyan-400" />
            ) : (
              <BookmarkPlus className="h-4 w-4 text-cyan-400" />
            )}
            <span>{isSavingRecord ? 'Syncing...' : 'Save Scenario'}</span>
          </button>

          <button
            id="ask-ai-from-dashboard-btn"
            onClick={() => onNavigate('ai-tips')}
            className="flex items-center space-x-2 rounded-xl bg-gradient-to-r from-indigo-600 to-cyan-600 px-4 py-2 text-xs font-semibold text-white shadow-lg shadow-indigo-600/20 hover:from-indigo-500 hover:to-cyan-500 transition"
          >
            <Sparkles className="h-4 w-4" />
            <span>AI Consultation</span>
          </button>
        </div>
      </div>

      {/* 6 Financial Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {/* 1. Monthly Income */}
        <div className="rounded-2xl border border-white/10 bg-[#0D1320]/80 p-4 backdrop-blur-xl shadow-lg hover:border-indigo-500/30 transition group">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-medium">Monthly Income</span>
            <div className="rounded-lg bg-indigo-500/10 p-2 text-indigo-400 group-hover:scale-110 transition">
              <Wallet className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-xl font-bold text-white tracking-tight">
              {formatCurrency(monthlyIncome, currency)}
            </div>
            <div className="mt-1 flex items-center text-[11px] text-emerald-400 font-medium">
              <CheckCircle className="h-3 w-3 mr-1" />
              <span>Gross Active Inflow</span>
            </div>
          </div>
        </div>

        {/* 2. Monthly Expenses */}
        <div className="rounded-2xl border border-white/10 bg-[#0D1320]/80 p-4 backdrop-blur-xl shadow-lg hover:border-white/20 transition group">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-medium">Monthly Expenses</span>
            <div className="rounded-lg bg-rose-500/10 p-2 text-rose-400 group-hover:scale-110 transition">
              <Receipt className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-xl font-bold text-white tracking-tight">
              {formatCurrency(monthlyExpenses, currency)}
            </div>
            <div className="mt-1 flex items-center text-[11px] text-slate-400">
              <span>{formatPercent(expensesPct)} of monthly income</span>
            </div>
          </div>
        </div>

        {/* 3. Credit Score */}
        <div
          onClick={() => onNavigate('credit')}
          className="rounded-2xl border border-white/10 bg-[#0D1320]/80 p-4 backdrop-blur-xl shadow-lg hover:border-cyan-500/30 transition group cursor-pointer"
        >
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-medium">Credit Score</span>
            <div className="rounded-lg bg-cyan-500/10 p-2 text-cyan-400 group-hover:scale-110 transition">
              <CreditCard className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-2">
            <div className="flex items-baseline space-x-2">
              <span className="text-xl font-bold text-white tracking-tight">{creditScore}</span>
              <span className="text-xs text-slate-400 font-medium">/ 850</span>
            </div>
            <div className="mt-1 flex items-center text-[11px] font-semibold text-cyan-300">
              <span>{creditTier} Tier</span>
              <ArrowUpRight className="h-3 w-3 ml-1" />
            </div>
          </div>
        </div>

        {/* 4. Existing EMI Obligations */}
        <div className="rounded-2xl border border-white/10 bg-[#0D1320]/80 p-4 backdrop-blur-xl shadow-lg hover:border-white/20 transition group">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-medium">Existing EMI</span>
            <div className="rounded-lg bg-amber-500/10 p-2 text-amber-400 group-hover:scale-110 transition">
              <Scale className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-xl font-bold text-white tracking-tight">
              {formatCurrency(existingEmi, currency)}
            </div>
            <div className="mt-1 flex items-center text-[11px] text-slate-400">
              <span>{profile.existingLoansCount} Active Loan(s)</span>
            </div>
          </div>
        </div>

        {/* 5. Estimated Loan Eligibility */}
        <div
          onClick={() => onNavigate('loan')}
          className="rounded-2xl border border-white/10 bg-[#0D1320]/80 p-4 backdrop-blur-xl shadow-lg hover:border-emerald-500/30 transition group cursor-pointer"
        >
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-medium">Est. Loan Eligibility</span>
            <div className="rounded-lg bg-emerald-500/10 p-2 text-emerald-400 group-hover:scale-110 transition">
              <ShieldCheck className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-xl font-bold text-emerald-400 tracking-tight">
              {formatCurrency(estimatedEligibleAmount, currency)}
            </div>
            <div className="mt-1 flex items-center text-[11px] text-slate-300">
              <span>Score: {eligibilityScore}/100</span>
              <ArrowUpRight className="h-3 w-3 ml-1 text-emerald-400" />
            </div>
          </div>
        </div>

        {/* 6. Debt-to-Income (DTI) */}
        <div className="rounded-2xl border border-white/10 bg-[#0D1320]/80 p-4 backdrop-blur-xl shadow-lg hover:border-white/20 transition group">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-medium">DTI Ratio</span>
            <div className="rounded-lg bg-purple-500/10 p-2 text-purple-400 group-hover:scale-110 transition">
              <TrendingUp className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-xl font-bold text-white tracking-tight">
              {formatPercent(debtToIncomeRatio)}
            </div>
            <div className="mt-1 flex items-center text-[11px]">
              <span
                className={`font-semibold ${
                  debtToIncomeRatio <= 35
                    ? 'text-emerald-400'
                    : debtToIncomeRatio <= 45
                    ? 'text-amber-400'
                    : 'text-rose-400'
                }`}
              >
                {debtToIncomeRatio <= 35
                  ? 'Healthy (<35%)'
                  : debtToIncomeRatio <= 45
                  ? 'Moderate (<45%)'
                  : 'High Risk (>45%)'}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Visual Analytics & Decision Support Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Chart 1: Monthly Cash Flow Distribution */}
        <div className="lg:col-span-6 rounded-2xl border border-white/10 bg-[#0D1320]/80 p-5 backdrop-blur-xl shadow-xl">
          <div className="flex items-center justify-between pb-3 border-b border-white/10">
            <div>
              <h3 className="text-sm font-semibold text-white">Monthly Cash Flow Breakdown</h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Proportional distribution of monthly earnings across commitments
              </p>
            </div>
            <div className="text-right">
              <span className="text-xs text-slate-400">Net Disposable</span>
              <p className="text-sm font-bold text-emerald-400">
                {formatCurrency(disposableIncome, currency)}
              </p>
            </div>
          </div>

          {/* Proportional Multi-Segment Progress Bar */}
          <div className="mt-6 space-y-2">
            <div className="h-5 w-full rounded-full bg-slate-800 overflow-hidden flex p-0.5 border border-white/10">
              <div
                style={{ width: `${Math.min(100, expensesPct)}%` }}
                className="h-full bg-gradient-to-r from-rose-500 to-rose-400 rounded-l-full transition-all duration-500"
                title={`Living Expenses: ${formatPercent(expensesPct)}`}
              />
              <div
                style={{ width: `${Math.min(100, emiPct)}%` }}
                className="h-full bg-gradient-to-r from-amber-500 to-amber-400 transition-all duration-500"
                title={`Existing EMIs: ${formatPercent(emiPct)}`}
              />
              <div
                style={{ width: `${Math.max(0, savingsPct)}%` }}
                className="h-full bg-gradient-to-r from-emerald-500 to-cyan-400 rounded-r-full transition-all duration-500"
                title={`Unallocated Surplus: ${formatPercent(savingsPct)}`}
              />
            </div>

            {/* Legend & Details */}
            <div className="grid grid-cols-3 gap-2 pt-3 text-xs">
              <div className="rounded-xl border border-white/5 bg-white/[0.02] p-2.5">
                <div className="flex items-center space-x-1.5">
                  <span className="h-2.5 w-2.5 rounded-full bg-rose-400" />
                  <span className="text-slate-400 font-medium">Expenses</span>
                </div>
                <div className="text-sm font-bold text-white mt-1">
                  {formatCurrency(monthlyExpenses, currency)}
                </div>
                <span className="text-[10px] text-slate-500">{formatPercent(expensesPct)}</span>
              </div>

              <div className="rounded-xl border border-white/5 bg-white/[0.02] p-2.5">
                <div className="flex items-center space-x-1.5">
                  <span className="h-2.5 w-2.5 rounded-full bg-amber-400" />
                  <span className="text-slate-400 font-medium">Existing EMI</span>
                </div>
                <div className="text-sm font-bold text-white mt-1">
                  {formatCurrency(existingEmi, currency)}
                </div>
                <span className="text-[10px] text-slate-500">{formatPercent(emiPct)}</span>
              </div>

              <div className="rounded-xl border border-white/5 bg-white/[0.02] p-2.5">
                <div className="flex items-center space-x-1.5">
                  <span className="h-2.5 w-2.5 rounded-full bg-emerald-400" />
                  <span className="text-slate-400 font-medium">Free Surplus</span>
                </div>
                <div className="text-sm font-bold text-emerald-400 mt-1">
                  {formatCurrency(savings, currency)}
                </div>
                <span className="text-[10px] text-slate-500">{formatPercent(savingsPct)}</span>
              </div>
            </div>
          </div>

          <div className="mt-4 rounded-xl border border-indigo-500/20 bg-indigo-500/5 p-3 flex items-start space-x-3 text-xs text-slate-300">
            <Sparkles className="h-4 w-4 text-cyan-400 flex-shrink-0 mt-0.5" />
            <div>
              <strong className="text-white">Underwriting Insight:</strong> Regulated lenders
              generally cap cumulative debt commitments at 40%–50% of monthly income. Your current
              total obligations consume{' '}
              <span className="font-semibold text-cyan-300">
                {formatPercent(emiPct + expensesPct)}
              </span>{' '}
              of income.
            </div>
          </div>
        </div>

        {/* Chart 2: Borrowing Capacity & Affordability Comparison */}
        <div className="lg:col-span-6 rounded-2xl border border-white/10 bg-[#0D1320]/80 p-5 backdrop-blur-xl shadow-xl">
          <div className="flex items-center justify-between pb-3 border-b border-white/10">
            <div>
              <h3 className="text-sm font-semibold text-white">Borrowing Affordability Comparison</h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Requested loan vs. algorithmic max borrowing ceiling
              </p>
            </div>
            <span
              className={`rounded-full px-2 py-0.5 text-xs font-semibold ${riskStyle.bg} ${riskStyle.text} border ${riskStyle.border}`}
            >
              {riskCategory}
            </span>
          </div>

          <div className="mt-5 space-y-4">
            {/* Requested Loan vs Estimated Eligible */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">Desired Loan Request</span>
                <span className="font-bold text-white">
                  {formatCurrency(desiredLoanAmount, currency)}
                </span>
              </div>
              <div className="h-3 w-full rounded-full bg-slate-800 overflow-hidden">
                <div
                  style={{
                    width: `${Math.min(
                      100,
                      (desiredLoanAmount /
                        Math.max(desiredLoanAmount, estimatedEligibleAmount, 1)) *
                        100
                    )}%`,
                  }}
                  className="h-full bg-indigo-500 rounded-full transition-all duration-500"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">Estimated Eligible Capacity</span>
                <span className="font-bold text-emerald-400">
                  {formatCurrency(estimatedEligibleAmount, currency)}
                </span>
              </div>
              <div className="h-3 w-full rounded-full bg-slate-800 overflow-hidden">
                <div
                  style={{
                    width: `${Math.min(
                      100,
                      (estimatedEligibleAmount /
                        Math.max(desiredLoanAmount, estimatedEligibleAmount, 1)) *
                        100
                    )}%`,
                  }}
                  className="h-full bg-gradient-to-r from-emerald-500 to-cyan-400 rounded-full transition-all duration-500"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">Max Permissible New EMI (FOIR Limit)</span>
                <span className="font-bold text-cyan-300">
                  {formatCurrency(maxSafeMonthlyEMI, currency)} / mo
                </span>
              </div>
              <div className="h-3 w-full rounded-full bg-slate-800 overflow-hidden">
                <div
                  style={{
                    width: `${Math.min(
                      100,
                      (maxSafeMonthlyEMI / Math.max(monthlyIncome * 0.5, 1)) * 100
                    )}%`,
                  }}
                  className="h-full bg-cyan-400 rounded-full transition-all duration-500"
                />
              </div>
            </div>
          </div>

          <div className="mt-5 pt-3 border-t border-white/10 flex flex-wrap items-center justify-between gap-2">
            <button
              onClick={() => onNavigate('loan')}
              className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center space-x-1"
            >
              <span>View In-Depth Underwriting Factors</span>
              <ArrowUpRight className="h-3.5 w-3.5" />
            </button>

            <button
              onClick={() => onNavigate('emi')}
              className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 flex items-center space-x-1"
            >
              <span>Explore EMI Amortization Schedule</span>
              <ArrowUpRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
