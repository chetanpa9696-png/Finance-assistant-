import React, { useState } from 'react';
import {
  Database,
  Download,
  Trash2,
  ExternalLink,
  CheckCircle2,
  AlertCircle,
  FileSpreadsheet,
  RefreshCw,
  Search,
  Filter,
  ArrowUpRight,
  Shield,
  Layers,
} from 'lucide-react';
import { SavedFinancialRecord, Currency, FinancialProfile } from '../types';
import { formatCurrency, getStatusBadgeClasses, getRiskBadgeClasses } from '../utils/formatters';

interface RecordsViewProps {
  records: SavedFinancialRecord[];
  isLoading: boolean;
  currency: Currency;
  onRefreshRecords: () => void;
  onDeleteRecord: (id: string) => void;
  onLoadProfile: (profile: Partial<FinancialProfile>) => void;
  sheetsConfigStatus?: {
    configured: boolean;
    sheetId?: string;
    mode: string;
  };
}

export const RecordsView: React.FC<RecordsViewProps> = ({
  records,
  isLoading,
  currency,
  onRefreshRecords,
  onDeleteRecord,
  onLoadProfile,
  sheetsConfigStatus,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const filteredRecords = records.filter((rec) => {
    const matchesSearch =
      rec.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      rec.employmentType.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === 'all' || rec.eligibilityStatus === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const handleExportCSV = () => {
    if (records.length === 0) return;

    const headers = [
      'Record ID',
      'Timestamp',
      'Applicant Name',
      'Monthly Income',
      'Monthly Expenses',
      'Credit Score',
      'Employment Type',
      'Desired Loan',
      'Tenure (Months)',
      'Estimated Eligible',
      'Estimated EMI',
      'Eligibility Status',
      'Risk Category',
    ];

    const rows = records.map((r) => [
      `"${r.id}"`,
      `"${r.timestamp}"`,
      `"${r.userName}"`,
      r.monthlyIncome,
      r.monthlyExpenses,
      r.creditScore,
      `"${r.employmentType}"`,
      r.desiredLoanAmount,
      r.loanTenureMonths,
      r.estimatedEligibleAmount,
      r.monthlyEMI,
      `"${r.eligibilityStatus}"`,
      `"${r.riskCategory}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `BFSI_Financial_Records_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportJSON = () => {
    if (records.length === 0) return;
    const jsonString = `data:text/json;charset=utf-8,${encodeURIComponent(
      JSON.stringify(records, null, 2)
    )}`;
    const link = document.createElement('a');
    link.setAttribute('href', jsonString);
    link.setAttribute('download', `BFSI_Financial_Records_${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDelete = async (id: string) => {
    setDeletingId(id);
    try {
      await onDeleteRecord(id);
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Header */}
      <div className="border-b border-white/10 pb-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <Database className="h-6 w-6 text-cyan-400" />
            <h2 className="text-2xl font-bold tracking-tight text-white">
              Financial Records Management
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Persisted audit records synchronized with Google Sheets cloud storage and local database
            backups.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={onRefreshRecords}
            disabled={isLoading}
            className="flex items-center space-x-1.5 rounded-xl border border-white/15 bg-white/5 px-3 py-2 text-xs font-semibold text-slate-200 hover:bg-white/10 transition"
            title="Refresh database records"
          >
            <RefreshCw className={`h-3.5 w-3.5 text-cyan-400 ${isLoading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>

          <button
            onClick={handleExportCSV}
            disabled={records.length === 0}
            className="flex items-center space-x-1.5 rounded-xl border border-white/15 bg-white/5 px-3 py-2 text-xs font-semibold text-slate-200 hover:bg-white/10 transition disabled:opacity-40"
          >
            <Download className="h-3.5 w-3.5 text-emerald-400" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={handleExportJSON}
            disabled={records.length === 0}
            className="flex items-center space-x-1.5 rounded-xl border border-white/15 bg-white/5 px-3 py-2 text-xs font-semibold text-slate-200 hover:bg-white/10 transition disabled:opacity-40"
          >
            <FileSpreadsheet className="h-3.5 w-3.5 text-indigo-400" />
            <span>JSON</span>
          </button>
        </div>
      </div>

      {/* Google Sheets Sync & Security Status Banner */}
      <div className="rounded-2xl border border-white/10 bg-[#0D1320]/80 p-5 backdrop-blur-xl shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start space-x-3">
            <div className="rounded-xl bg-emerald-500/10 p-2 text-emerald-400 mt-0.5">
              <FileSpreadsheet className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h4 className="text-sm font-semibold text-white">
                  Google Sheets & Data Layer Architecture
                </h4>
                <span
                  className={`rounded-full px-2 py-0.5 text-[10px] font-semibold border ${
                    sheetsConfigStatus?.configured
                      ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
                      : 'bg-indigo-500/10 text-indigo-300 border-indigo-500/30'
                  }`}
                >
                  {sheetsConfigStatus?.configured ? 'Sheets Live Connected' : 'Server Cache Active'}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1 max-w-2xl">
                Records are securely stored on the server via `POST /api/save-record` and `GET
                /api/records`. When `GOOGLE_SHEET_ID` and credentials are supplied, data mirrors
                directly into your Google Sheet without exposing credentials to the client.
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2 text-xs text-slate-300">
            <span className="font-semibold text-white">{records.length}</span> records persisted
          </div>
        </div>
      </div>

      {/* Search & Filter Controls */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search records by applicant..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full rounded-xl border border-white/15 bg-white/5 pl-9 pr-3.5 py-2 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition"
          />
        </div>

        <div className="flex items-center space-x-2 w-full sm:w-auto">
          <Filter className="h-4 w-4 text-slate-400" />
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="rounded-xl border border-white/15 bg-[#070B14] px-3 py-2 text-xs text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition"
          >
            <option value="all">All Eligibility Outcomes</option>
            <option value="Likely Eligible">Likely Eligible</option>
            <option value="Potentially Eligible">Potentially Eligible</option>
            <option value="Needs Improvement">Needs Improvement</option>
          </select>
        </div>
      </div>

      {/* Records Table */}
      <div className="rounded-2xl border border-white/10 bg-[#0D1320]/80 backdrop-blur-xl shadow-xl overflow-hidden">
        {filteredRecords.length === 0 ? (
          <div className="p-12 text-center text-slate-400 space-y-3">
            <Database className="h-10 w-10 mx-auto text-slate-600" />
            <p className="text-sm font-semibold text-slate-300">No matching financial records</p>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              Run an assessment on the Dashboard or Loan Eligibility page and click "Save Scenario"
              to persist records here.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="border-b border-white/10 bg-white/[0.02] text-[11px] uppercase tracking-wider text-slate-400">
                <tr>
                  <th className="py-3 px-4">Date / Applicant</th>
                  <th className="py-3 px-4 text-right">Income / Outlays</th>
                  <th className="py-3 px-4 text-center">Credit Score</th>
                  <th className="py-3 px-4 text-right">Desired / Eligible</th>
                  <th className="py-3 px-4 text-center">Verdict</th>
                  <th className="py-3 px-4 text-center">Risk Level</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {filteredRecords.map((rec) => {
                  const statusStyle = getStatusBadgeClasses(rec.eligibilityStatus);
                  const riskStyle = getRiskBadgeClasses(rec.riskCategory);
                  const formattedDate = new Date(rec.timestamp).toLocaleDateString(undefined, {
                    month: 'short',
                    day: 'numeric',
                    year: 'numeric',
                  });

                  return (
                    <tr key={rec.id} className="hover:bg-white/[0.02] transition">
                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-white">{rec.userName}</div>
                        <div className="text-[11px] text-slate-400 flex items-center space-x-1.5 mt-0.5">
                          <span>{formattedDate}</span>
                          <span>•</span>
                          <span className="capitalize">{rec.employmentType}</span>
                        </div>
                      </td>

                      <td className="py-3.5 px-4 text-right">
                        <div className="font-medium text-emerald-400">
                          {formatCurrency(rec.monthlyIncome, rec.currency || currency)}
                        </div>
                        <div className="text-[11px] text-slate-400 mt-0.5">
                          Exp: {formatCurrency(rec.monthlyExpenses, rec.currency || currency)}
                        </div>
                      </td>

                      <td className="py-3.5 px-4 text-center">
                        <span className="font-bold text-cyan-300 bg-cyan-500/10 border border-cyan-500/20 px-2 py-0.5 rounded-md">
                          {rec.creditScore}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-right">
                        <div className="font-bold text-white">
                          {formatCurrency(rec.desiredLoanAmount, rec.currency || currency)}
                        </div>
                        <div className="text-[11px] text-emerald-400 mt-0.5">
                          Cap: {formatCurrency(rec.estimatedEligibleAmount, rec.currency || currency)}
                        </div>
                      </td>

                      <td className="py-3.5 px-4 text-center">
                        <span
                          className={`rounded-full px-2.5 py-0.5 text-[11px] font-semibold ${statusStyle.bg} ${statusStyle.text} border ${statusStyle.border}`}
                        >
                          {rec.eligibilityStatus}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-center">
                        <span
                          className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${riskStyle.bg} ${riskStyle.text} border ${riskStyle.border}`}
                        >
                          {rec.riskCategory}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end space-x-2">
                          <button
                            onClick={() =>
                              onLoadProfile({
                                fullName: rec.userName,
                                monthlyIncome: rec.monthlyIncome,
                                monthlyExpenses: rec.monthlyExpenses,
                                creditScore: rec.creditScore,
                                desiredLoanAmount: rec.desiredLoanAmount,
                                loanTenureMonths: rec.loanTenureMonths,
                                employmentType: rec.employmentType as any,
                              })
                            }
                            className="rounded-lg border border-white/10 bg-white/5 px-2 py-1 text-[11px] font-medium text-slate-300 hover:bg-white/10 hover:text-white transition flex items-center space-x-1"
                            title="Load profile parameters into active workspace"
                          >
                            <span>Load</span>
                            <ArrowUpRight className="h-3 w-3" />
                          </button>

                          <button
                            onClick={() => handleDelete(rec.id)}
                            disabled={deletingId === rec.id}
                            className="rounded-lg p-1 text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 transition"
                            title="Delete record"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
