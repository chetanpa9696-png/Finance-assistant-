import React, { useState } from 'react';
import {
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  TrendingUp,
  BookmarkPlus,
  RefreshCw,
  Sparkles,
  ArrowRight,
  Info,
} from 'lucide-react';
import {
  FinancialProfile,
  Currency,
  LoanEligibilityResult,
  EmploymentType,
  ValidationErrors,
} from '../types';
import { formatCurrency, formatPercent, getStatusBadgeClasses, getRiskBadgeClasses } from '../utils/formatters';
import { validateLoanEligibilityForm } from '../utils/validation';
import { evaluateLoanEligibility } from '../utils/calculations';

interface LoanEligibilityViewProps {
  profile: FinancialProfile;
  onUpdateProfile: (updated: Partial<FinancialProfile>) => void;
  currency: Currency;
  onSaveRecord: () => void;
  isSavingRecord: boolean;
  onNavigateToAI: () => void;
}

export const LoanEligibilityView: React.FC<LoanEligibilityViewProps> = ({
  profile,
  onUpdateProfile,
  currency,
  onSaveRecord,
  isSavingRecord,
  onNavigateToAI,
}) => {
  const [formData, setFormData] = useState<FinancialProfile>(profile);
  const [errors, setErrors] = useState<ValidationErrors>({});
  const [result, setResult] = useState<LoanEligibilityResult>(() =>
    evaluateLoanEligibility(profile)
  );

  const handleChange = (field: keyof FinancialProfile, value: unknown) => {
    const updated = { ...formData, [field]: value };
    setFormData(updated);

    // Clear specific field error
    if (errors[field]) {
      setErrors((prev) => {
        const next = { ...prev };
        delete next[field];
        return next;
      });
    }

    // Dynamic real-time calculation preview
    try {
      const newResult = evaluateLoanEligibility(updated);
      setResult(newResult);
      onUpdateProfile(updated);
    } catch {
      // Keep previous result if input is mid-typing
    }
  };

  const handleEvaluateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const validation = validateLoanEligibilityForm(formData);
    if (!validation.isValid) {
      setErrors(validation.errors);
      return;
    }

    setErrors({});
    const newResult = evaluateLoanEligibility(formData);
    setResult(newResult);
    onUpdateProfile(formData);
  };

  const statusStyle = getStatusBadgeClasses(result.status);
  const riskStyle = getRiskBadgeClasses(result.riskCategory);

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Header */}
      <div className="border-b border-white/10 pb-4 flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <div className="flex items-center space-x-2">
            <ShieldCheck className="h-6 w-6 text-indigo-400" />
            <h2 className="text-2xl font-bold tracking-tight text-white">
              Retail Loan Eligibility Engine
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Algorithmic underwriting assessment analyzing credit bands, debt burden ratios (FOIR),
            and disposable income cushions.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            type="button"
            onClick={onSaveRecord}
            disabled={isSavingRecord}
            className="flex items-center space-x-1.5 rounded-xl border border-white/15 bg-white/5 px-3.5 py-2 text-xs font-semibold text-slate-200 hover:bg-white/10 transition disabled:opacity-50"
          >
            {isSavingRecord ? (
              <RefreshCw className="h-4 w-4 animate-spin text-cyan-400" />
            ) : (
              <BookmarkPlus className="h-4 w-4 text-cyan-400" />
            )}
            <span>{isSavingRecord ? 'Saving...' : 'Save Assessment'}</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Form Inputs with Validation */}
        <div className="lg:col-span-6">
          <form
            onSubmit={handleEvaluateSubmit}
            className="rounded-2xl border border-white/10 bg-[#0D1320]/80 p-6 backdrop-blur-xl shadow-xl space-y-5"
          >
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <h3 className="text-sm font-semibold text-white uppercase tracking-wider">
                Applicant Financial Parameters
              </h3>
              <span className="text-[11px] text-slate-400">All fields required</span>
            </div>

            {/* Full Name & Age */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="sm:col-span-2">
                <label
                  htmlFor="fullNameInput"
                  className="block text-xs font-medium text-slate-300 mb-1"
                >
                  Full Name
                </label>
                <input
                  id="fullNameInput"
                  type="text"
                  value={formData.fullName}
                  onChange={(e) => handleChange('fullName', e.target.value)}
                  className={`w-full rounded-xl border bg-white/5 px-3.5 py-2.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition ${
                    errors.fullName ? 'border-rose-500' : 'border-white/15'
                  }`}
                  placeholder="e.g., Sarah Chen"
                />
                {errors.fullName && (
                  <p className="mt-1 text-xs text-rose-400 flex items-center">
                    <AlertCircle className="h-3 w-3 mr-1" />
                    {errors.fullName}
                  </p>
                )}
              </div>

              <div>
                <label htmlFor="ageInput" className="block text-xs font-medium text-slate-300 mb-1">
                  Age (Years)
                </label>
                <input
                  id="ageInput"
                  type="number"
                  min={18}
                  max={85}
                  value={formData.age || ''}
                  onChange={(e) => handleChange('age', Number(e.target.value))}
                  className={`w-full rounded-xl border bg-white/5 px-3.5 py-2.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition ${
                    errors.age ? 'border-rose-500' : 'border-white/15'
                  }`}
                  placeholder="32"
                />
                {errors.age && (
                  <p className="mt-1 text-xs text-rose-400 flex items-center">
                    <AlertCircle className="h-3 w-3 mr-1" />
                    {errors.age}
                  </p>
                )}
              </div>
            </div>

            {/* Monthly Income & Expenses */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label
                  htmlFor="monthlyIncomeInput"
                  className="block text-xs font-medium text-slate-300 mb-1"
                >
                  Monthly Income ({currency})
                </label>
                <input
                  id="monthlyIncomeInput"
                  type="number"
                  min={0}
                  step={100}
                  value={formData.monthlyIncome || ''}
                  onChange={(e) => handleChange('monthlyIncome', Number(e.target.value))}
                  className={`w-full rounded-xl border bg-white/5 px-3.5 py-2.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition ${
                    errors.monthlyIncome ? 'border-rose-500' : 'border-white/15'
                  }`}
                  placeholder="8500"
                />
                {errors.monthlyIncome && (
                  <p className="mt-1 text-xs text-rose-400 flex items-center">
                    <AlertCircle className="h-3 w-3 mr-1" />
                    {errors.monthlyIncome}
                  </p>
                )}
              </div>

              <div>
                <label
                  htmlFor="monthlyExpensesInput"
                  className="block text-xs font-medium text-slate-300 mb-1"
                >
                  Monthly Expenses ({currency})
                </label>
                <input
                  id="monthlyExpensesInput"
                  type="number"
                  min={0}
                  step={50}
                  value={formData.monthlyExpenses || ''}
                  onChange={(e) => handleChange('monthlyExpenses', Number(e.target.value))}
                  className={`w-full rounded-xl border bg-white/5 px-3.5 py-2.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition ${
                    errors.monthlyExpenses ? 'border-rose-500' : 'border-white/15'
                  }`}
                  placeholder="2800"
                />
                {errors.monthlyExpenses && (
                  <p className="mt-1 text-xs text-rose-400 flex items-center">
                    <AlertCircle className="h-3 w-3 mr-1" />
                    {errors.monthlyExpenses}
                  </p>
                )}
              </div>
            </div>

            {/* Existing EMI & Active Loans */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label
                  htmlFor="existingEmiInput"
                  className="block text-xs font-medium text-slate-300 mb-1"
                >
                  Existing Monthly EMIs ({currency})
                </label>
                <input
                  id="existingEmiInput"
                  type="number"
                  min={0}
                  step={25}
                  value={formData.existingEmi ?? ''}
                  onChange={(e) => handleChange('existingEmi', Number(e.target.value))}
                  className={`w-full rounded-xl border bg-white/5 px-3.5 py-2.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition ${
                    errors.existingEmi ? 'border-rose-500' : 'border-white/15'
                  }`}
                  placeholder="450"
                />
                {errors.existingEmi && (
                  <p className="mt-1 text-xs text-rose-400 flex items-center">
                    <AlertCircle className="h-3 w-3 mr-1" />
                    {errors.existingEmi}
                  </p>
                )}
              </div>

              <div>
                <label
                  htmlFor="existingLoansCountInput"
                  className="block text-xs font-medium text-slate-300 mb-1"
                >
                  Number of Active Loans
                </label>
                <input
                  id="existingLoansCountInput"
                  type="number"
                  min={0}
                  max={20}
                  value={formData.existingLoansCount ?? ''}
                  onChange={(e) => handleChange('existingLoansCount', Number(e.target.value))}
                  className="w-full rounded-xl border border-white/15 bg-white/5 px-3.5 py-2.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition"
                  placeholder="1"
                />
              </div>
            </div>

            {/* Employment Type & Duration */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label
                  htmlFor="employmentTypeSelect"
                  className="block text-xs font-medium text-slate-300 mb-1"
                >
                  Employment Type
                </label>
                <select
                  id="employmentTypeSelect"
                  value={formData.employmentType}
                  onChange={(e) => handleChange('employmentType', e.target.value as EmploymentType)}
                  className="w-full rounded-xl border border-white/15 bg-[#070B14] px-3.5 py-2.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition"
                >
                  <option value="salaried">Salaried (Corporate / Public)</option>
                  <option value="self-employed">Self-Employed Professional</option>
                  <option value="business-owner">Business Owner / Enterprise</option>
                  <option value="freelancer">Freelancer / Independent Contractor</option>
                  <option value="other">Other Employment</option>
                </select>
              </div>

              <div>
                <label
                  htmlFor="employmentDurationInput"
                  className="block text-xs font-medium text-slate-300 mb-1"
                >
                  Duration in Role (Years)
                </label>
                <input
                  id="employmentDurationInput"
                  type="number"
                  min={0}
                  max={50}
                  step={0.5}
                  value={formData.employmentDurationYears || ''}
                  onChange={(e) =>
                    handleChange('employmentDurationYears', Number(e.target.value))
                  }
                  className={`w-full rounded-xl border bg-white/5 px-3.5 py-2.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition ${
                    errors.employmentDurationYears ? 'border-rose-500' : 'border-white/15'
                  }`}
                  placeholder="5"
                />
                {errors.employmentDurationYears && (
                  <p className="mt-1 text-xs text-rose-400 flex items-center">
                    <AlertCircle className="h-3 w-3 mr-1" />
                    {errors.employmentDurationYears}
                  </p>
                )}
              </div>
            </div>

            {/* Credit Score & Desired Loan Amount */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label htmlFor="creditScoreInput" className="text-xs font-medium text-slate-300">
                    Credit Score (300 - 850)
                  </label>
                  <span className="text-[11px] text-cyan-400 font-semibold">
                    {formData.creditScore}
                  </span>
                </div>
                <input
                  id="creditScoreInput"
                  type="number"
                  min={300}
                  max={850}
                  value={formData.creditScore || ''}
                  onChange={(e) => handleChange('creditScore', Number(e.target.value))}
                  className={`w-full rounded-xl border bg-white/5 px-3.5 py-2.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition ${
                    errors.creditScore ? 'border-rose-500' : 'border-white/15'
                  }`}
                  placeholder="750"
                />
                {errors.creditScore && (
                  <p className="mt-1 text-xs text-rose-400 flex items-center">
                    <AlertCircle className="h-3 w-3 mr-1" />
                    {errors.creditScore}
                  </p>
                )}
              </div>

              <div>
                <label
                  htmlFor="desiredLoanAmountInput"
                  className="block text-xs font-medium text-slate-300 mb-1"
                >
                  Desired Loan Amount ({currency})
                </label>
                <input
                  id="desiredLoanAmountInput"
                  type="number"
                  min={1000}
                  step={5000}
                  value={formData.desiredLoanAmount || ''}
                  onChange={(e) => handleChange('desiredLoanAmount', Number(e.target.value))}
                  className={`w-full rounded-xl border bg-white/5 px-3.5 py-2.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition ${
                    errors.desiredLoanAmount ? 'border-rose-500' : 'border-white/15'
                  }`}
                  placeholder="250000"
                />
                {errors.desiredLoanAmount && (
                  <p className="mt-1 text-xs text-rose-400 flex items-center">
                    <AlertCircle className="h-3 w-3 mr-1" />
                    {errors.desiredLoanAmount}
                  </p>
                )}
              </div>
            </div>

            {/* Loan Tenure */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label htmlFor="loanTenureInput" className="text-xs font-medium text-slate-300">
                  Loan Tenure (Months)
                </label>
                <span className="text-[11px] text-slate-400 font-medium">
                  {formData.loanTenureMonths} months ({(formData.loanTenureMonths / 12).toFixed(1)}{' '}
                  years)
                </span>
              </div>
              <input
                id="loanTenureInput"
                type="number"
                min={6}
                max={480}
                step={6}
                value={formData.loanTenureMonths || ''}
                onChange={(e) => handleChange('loanTenureMonths', Number(e.target.value))}
                className={`w-full rounded-xl border bg-white/5 px-3.5 py-2.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition ${
                  errors.loanTenureMonths ? 'border-rose-500' : 'border-white/15'
                }`}
                placeholder="240"
              />
              {errors.loanTenureMonths && (
                <p className="mt-1 text-xs text-rose-400 flex items-center">
                  <AlertCircle className="h-3 w-3 mr-1" />
                  {errors.loanTenureMonths}
                </p>
              )}
            </div>

            <button
              type="submit"
              id="recalculate-eligibility-btn"
              className="w-full rounded-xl bg-gradient-to-r from-indigo-600 via-indigo-500 to-cyan-600 py-3 text-sm font-semibold text-white shadow-lg shadow-indigo-500/25 hover:from-indigo-500 hover:to-cyan-500 transition active:scale-[0.99]"
            >
              Recalculate & Re-Score Application
            </button>
          </form>
        </div>

        {/* Right Column: Transparent Decision & Scoring Breakdown */}
        <div className="lg:col-span-6 space-y-6">
          {/* Main Status & Eligible Amount Card */}
          <div className="rounded-2xl border border-white/10 bg-[#0D1320]/80 p-6 backdrop-blur-xl shadow-xl">
            <div className="flex items-center justify-between pb-4 border-b border-white/10">
              <div>
                <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold">
                  Underwriting Verdict
                </span>
                <div className="flex items-center space-x-2 mt-1">
                  <span
                    className={`rounded-full px-3 py-1 text-sm font-bold ${statusStyle.bg} ${statusStyle.text} border ${statusStyle.border}`}
                  >
                    {result.status}
                  </span>
                  <span
                    className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${riskStyle.bg} ${riskStyle.text} border ${riskStyle.border}`}
                  >
                    {result.riskCategory}
                  </span>
                </div>
              </div>

              {/* Score Gauge Circle */}
              <div className="text-center">
                <div className="relative inline-flex items-center justify-center">
                  <svg className="w-16 h-16 transform -rotate-90">
                    <circle
                      cx="32"
                      cy="32"
                      r="28"
                      stroke="currentColor"
                      strokeWidth="5"
                      className="text-slate-800"
                      fill="transparent"
                    />
                    <circle
                      cx="32"
                      cy="32"
                      r="28"
                      stroke="currentColor"
                      strokeWidth="5"
                      className="text-cyan-400 transition-all duration-700"
                      fill="transparent"
                      strokeDasharray={175.9}
                      strokeDashoffset={175.9 - (175.9 * result.eligibilityScore) / 100}
                      strokeLinecap="round"
                    />
                  </svg>
                  <span className="absolute text-sm font-bold text-white">
                    {result.eligibilityScore}
                  </span>
                </div>
                <span className="block text-[10px] text-slate-400 font-medium mt-0.5">
                  Score / 100
                </span>
              </div>
            </div>

            {/* Numbers: Estimated Eligible vs Desired */}
            <div className="grid grid-cols-2 gap-4 mt-5">
              <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/5 p-4">
                <span className="text-xs text-slate-400">Estimated Eligible Amount</span>
                <div className="text-2xl font-extrabold text-emerald-400 mt-1">
                  {formatCurrency(result.estimatedEligibleAmount, currency)}
                </div>
                <span className="text-[11px] text-slate-400 mt-1 block">
                  Based on 50% max FOIR ceiling
                </span>
              </div>

              <div className="rounded-xl border border-white/10 bg-white/5 p-4">
                <span className="text-xs text-slate-400">Requested Amount</span>
                <div className="text-2xl font-extrabold text-white mt-1">
                  {formatCurrency(result.requestedAmount, currency)}
                </div>
                <span className="text-[11px] text-slate-400 mt-1 block">
                  Est. EMI: {formatCurrency(result.monthlyEstimatedEMI, currency)}/mo
                </span>
              </div>
            </div>

            {/* Disposable Income & DTI */}
            <div className="mt-4 grid grid-cols-2 gap-3 pt-3 border-t border-white/10 text-xs">
              <div>
                <span className="text-slate-400">Disposable Monthly Cash:</span>
                <p className="font-bold text-slate-200 mt-0.5">
                  {formatCurrency(result.disposableIncome, currency)}
                </p>
              </div>
              <div>
                <span className="text-slate-400">Current Debt Burden (DTI):</span>
                <p className="font-bold text-slate-200 mt-0.5">
                  {formatPercent(result.debtToIncomeRatio)}
                </p>
              </div>
            </div>
          </div>

          {/* Factor Assessments (Scoring Breakdown) */}
          <div className="rounded-2xl border border-white/10 bg-[#0D1320]/80 p-5 backdrop-blur-xl shadow-xl">
            <h4 className="text-xs font-semibold text-white uppercase tracking-wider mb-3">
              Factor Weighting & Diagnostic Breakdown
            </h4>

            <div className="space-y-3">
              {result.factorAssessments.map((factor) => (
                <div
                  key={factor.name}
                  className="rounded-xl border border-white/5 bg-white/[0.02] p-3 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-white">{factor.name}</span>
                    <div className="flex items-center space-x-2">
                      <span className="text-[10px] text-slate-400">
                        Weight: {factor.weight}%
                      </span>
                      <span
                        className={`font-bold ${
                          factor.status === 'positive'
                            ? 'text-emerald-400'
                            : factor.status === 'neutral'
                            ? 'text-amber-400'
                            : 'text-rose-400'
                        }`}
                      >
                        {factor.score}/100
                      </span>
                    </div>
                  </div>
                  <div className="mt-1.5 h-1.5 w-full rounded-full bg-slate-800 overflow-hidden">
                    <div
                      style={{ width: `${factor.score}%` }}
                      className={`h-full rounded-full ${
                        factor.status === 'positive'
                          ? 'bg-emerald-500'
                          : factor.status === 'neutral'
                          ? 'bg-amber-500'
                          : 'bg-rose-500'
                      }`}
                    />
                  </div>
                  <p className="mt-1.5 text-[11px] text-slate-400">{factor.description}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Key Positive Factors & Risk Flags */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="rounded-2xl border border-emerald-500/20 bg-emerald-500/5 p-4">
              <div className="flex items-center space-x-1.5 text-emerald-400 text-xs font-semibold uppercase tracking-wider mb-2">
                <CheckCircle2 className="h-4 w-4" />
                <span>Key Positive Factors</span>
              </div>
              <ul className="space-y-1.5 text-xs text-slate-300">
                {result.keyPositiveFactors.map((item, idx) => (
                  <li key={idx} className="flex items-start space-x-1.5">
                    <span className="text-emerald-400 font-bold">•</span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="rounded-2xl border border-rose-500/20 bg-rose-500/5 p-4">
              <div className="flex items-center space-x-1.5 text-rose-400 text-xs font-semibold uppercase tracking-wider mb-2">
                <AlertCircle className="h-4 w-4" />
                <span>Risk Flags & Mitigations</span>
              </div>
              <ul className="space-y-1.5 text-xs text-slate-300">
                {result.keyRiskFactors.map((item, idx) => (
                  <li key={idx} className="flex items-start space-x-1.5">
                    <span className="text-rose-400 font-bold">•</span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Actionable Suggestions & AI Consultation link */}
          <div className="rounded-2xl border border-indigo-500/30 bg-indigo-500/10 p-4 flex items-center justify-between text-xs">
            <div className="space-y-1 pr-3">
              <span className="font-semibold text-white flex items-center space-x-1.5">
                <Sparkles className="h-4 w-4 text-cyan-400" />
                <span>Need Personalized Improvement Recommendations?</span>
              </span>
              <p className="text-slate-300">
                Let the AI Advisor generate tailored debt reduction and loan-readiness steps.
              </p>
            </div>
            <button
              onClick={onNavigateToAI}
              className="flex-shrink-0 rounded-xl bg-indigo-600 px-3.5 py-2 font-semibold text-white hover:bg-indigo-500 transition flex items-center space-x-1"
            >
              <span>Ask AI</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>

          {/* Regulatory Disclaimer */}
          <div className="rounded-xl border border-white/5 bg-white/[0.02] p-3 text-[11px] text-slate-400 flex items-start space-x-2">
            <Info className="h-4 w-4 text-slate-500 flex-shrink-0 mt-0.5" />
            <p>
              <strong>Educational Estimate:</strong> All eligibility figures represent mathematical
              estimates based on standard Fixed Obligation to Income Ratio (FOIR) criteria and credit
              multipliers. This tool does not constitute a guaranteed loan sanction, underwriting
              commitment, or binding offer by any lending institution.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
