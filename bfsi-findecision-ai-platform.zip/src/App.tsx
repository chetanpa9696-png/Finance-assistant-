import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Header, NavTab } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { DashboardView } from './components/DashboardView';
import { LoanEligibilityView } from './components/LoanEligibilityView';
import { CreditAnalyzerView } from './components/CreditAnalyzerView';
import { EMICalculatorView } from './components/EMICalculatorView';
import { AITipsView } from './components/AITipsView';
import { RecordsView } from './components/RecordsView';
import { PrivacyNoticeModal } from './components/PrivacyNoticeModal';
import { MethodologyModal } from './components/MethodologyModal';
import { PRESET_PROFILES } from './data/sampleProfiles';
import {
  FinancialProfile,
  Currency,
  SavedFinancialRecord,
  LoanEligibilityResult,
} from './types';
import { evaluateLoanEligibility } from './utils/calculations';
import { CheckCircle2, ShieldAlert, X } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  const [currency, setCurrency] = useState<Currency>('USD');
  const [profile, setProfile] = useState<FinancialProfile>(PRESET_PROFILES[0].profile);
  const [records, setRecords] = useState<SavedFinancialRecord[]>([]);
  const [isLoadingRecords, setIsLoadingRecords] = useState<boolean>(false);
  const [isSavingRecord, setIsSavingRecord] = useState<boolean>(false);
  const [notification, setNotification] = useState<{
    type: 'success' | 'error';
    message: string;
  } | null>(null);

  // Modals state
  const [isPrivacyOpen, setIsPrivacyOpen] = useState(false);
  const [isMethodologyOpen, setIsMethodologyOpen] = useState(false);
  const [configStatus, setConfigStatus] = useState<{
    configured: boolean;
    sheetId?: string;
    mode: string;
  }>({
    configured: false,
    mode: 'heuristic-engine',
  });

  // Calculate eligibility in real-time
  const eligibilityResult: LoanEligibilityResult = useMemo(() => {
    return evaluateLoanEligibility(profile);
  }, [profile]);

  // Fetch persisted records from backend
  const fetchRecords = useCallback(async () => {
    setIsLoadingRecords(true);
    try {
      const res = await fetch('/api/records');
      if (res.ok) {
        const data = await res.json();
        if (data.records && Array.isArray(data.records)) {
          setRecords(data.records);
        }
      }
    } catch (err) {
      console.warn('Could not fetch records from backend:', err);
    } finally {
      setIsLoadingRecords(false);
    }
  }, []);

  // Fetch backend config status
  const fetchConfigStatus = useCallback(async () => {
    try {
      const res = await fetch('/api/config-status');
      if (res.ok) {
        const data = await res.json();
        setConfigStatus({
          configured: Boolean(data.sheetsActive),
          mode: data.mode || 'heuristic-engine',
        });
      }
    } catch (err) {
      // Ignored in dev preview
    }
  }, []);

  useEffect(() => {
    fetchRecords();
    fetchConfigStatus();
  }, [fetchRecords, fetchConfigStatus]);

  // Save current profile scenario to backend & Google Sheets
  const handleSaveRecord = async () => {
    setIsSavingRecord(true);
    try {
      const payload = {
        userName: profile.fullName || 'Applicant',
        monthlyIncome: profile.monthlyIncome,
        monthlyExpenses: profile.monthlyExpenses,
        creditScore: profile.creditScore,
        employmentType: profile.employmentType,
        desiredLoanAmount: profile.desiredLoanAmount,
        loanTenureMonths: profile.loanTenureMonths,
        estimatedEligibleAmount: eligibilityResult.estimatedEligibleAmount,
        monthlyEMI: eligibilityResult.monthlyEstimatedEMI,
        eligibilityStatus: eligibilityResult.status,
        riskCategory: eligibilityResult.riskCategory,
        aiSummary: `Score: ${eligibilityResult.eligibilityScore}/100, DTI: ${eligibilityResult.debtToIncomeRatio}%`,
        currency,
      };

      const res = await fetch('/api/save-record', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        throw new Error('Save failed');
      }

      const data = await res.json();
      if (data.record) {
        setRecords((prev) => [data.record, ...prev]);
        setNotification({
          type: 'success',
          message: data.message || 'Scenario successfully saved to financial records!',
        });
      }
    } catch (err) {
      console.error('Save record error:', err);
      setNotification({
        type: 'error',
        message: "We couldn't save your record right now. Please try again.",
      });
    } finally {
      setIsSavingRecord(false);
      setTimeout(() => setNotification(null), 5000);
    }
  };

  // Delete record handler
  const handleDeleteRecord = async (id: string) => {
    try {
      const res = await fetch(`/api/records/${id}`, { method: 'DELETE' });
      if (res.ok) {
        setRecords((prev) => prev.filter((r) => r.id !== id));
        setNotification({
          type: 'success',
          message: 'Record removed from persistent storage.',
        });
      }
    } catch (err) {
      console.error('Delete record error:', err);
    }
    setTimeout(() => setNotification(null), 4000);
  };

  // Update profile from any child view
  const handleUpdateProfile = (updated: Partial<FinancialProfile>) => {
    setProfile((prev) => ({ ...prev, ...updated }));
  };

  // Apply preset scenario
  const handleApplyPreset = (presetProfile: FinancialProfile) => {
    setProfile(presetProfile);
    setNotification({
      type: 'success',
      message: `Loaded scenario profile for ${presetProfile.fullName}!`,
    });
    setTimeout(() => setNotification(null), 3500);
  };

  return (
    <div className="min-h-screen bg-[#070B14] text-[#F8FAFC] flex flex-col selection:bg-indigo-500 selection:text-white">
      {/* Toast Notification */}
      {notification && (
        <div
          role="status"
          className={`fixed bottom-6 right-6 z-50 flex items-center space-x-3 rounded-2xl border px-4 py-3 text-xs font-semibold shadow-2xl backdrop-blur-md animate-slideUp ${
            notification.type === 'success'
              ? 'border-emerald-500/30 bg-emerald-950/90 text-emerald-200'
              : 'border-rose-500/30 bg-rose-950/90 text-rose-200'
          }`}
        >
          {notification.type === 'success' ? (
            <CheckCircle2 className="h-4 w-4 text-emerald-400" />
          ) : (
            <ShieldAlert className="h-4 w-4 text-rose-400" />
          )}
          <span>{notification.message}</span>
          <button
            onClick={() => setNotification(null)}
            className="ml-2 text-white/50 hover:text-white"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      )}

      {/* App Header */}
      <Header
        activeTab={activeTab}
        onTabChange={setActiveTab}
        currency={currency}
        onCurrencyChange={setCurrency}
        onOpenPrivacy={() => setIsPrivacyOpen(true)}
        onOpenMethodology={() => setIsMethodologyOpen(true)}
        recordsCount={records.length}
      />

      {/* Hero Section (Rendered on Dashboard) */}
      {activeTab === 'dashboard' && (
        <HeroSection onNavigate={setActiveTab} onApplyPreset={handleApplyPreset} />
      )}

      {/* Main Content Area */}
      <main className="flex-1 mx-auto max-w-7xl w-full px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'dashboard' && (
          <DashboardView
            profile={profile}
            eligibilityResult={eligibilityResult}
            currency={currency}
            onNavigate={setActiveTab}
            onSaveRecord={handleSaveRecord}
            isSavingRecord={isSavingRecord}
          />
        )}

        {activeTab === 'loan' && (
          <LoanEligibilityView
            profile={profile}
            onUpdateProfile={handleUpdateProfile}
            currency={currency}
            onSaveRecord={handleSaveRecord}
            isSavingRecord={isSavingRecord}
            onNavigateToAI={() => setActiveTab('ai-tips')}
          />
        )}

        {activeTab === 'credit' && (
          <CreditAnalyzerView
            initialScore={profile.creditScore}
            currency={currency}
            onUpdateScore={(newScore) => handleUpdateProfile({ creditScore: newScore })}
            onNavigateToLoan={() => setActiveTab('loan')}
          />
        )}

        {activeTab === 'emi' && (
          <EMICalculatorView
            initialPrincipal={profile.desiredLoanAmount}
            initialTenureMonths={profile.loanTenureMonths}
            currency={currency}
          />
        )}

        {activeTab === 'ai-tips' && (
          <AITipsView
            profile={profile}
            currency={currency}
            onUpdateProfile={handleUpdateProfile}
          />
        )}

        {activeTab === 'records' && (
          <RecordsView
            records={records}
            isLoading={isLoadingRecords}
            currency={currency}
            onRefreshRecords={fetchRecords}
            onDeleteRecord={handleDeleteRecord}
            onLoadProfile={(loadedProfile) => {
              handleUpdateProfile(loadedProfile);
              setActiveTab('dashboard');
              setNotification({
                type: 'success',
                message: 'Historical profile parameters loaded into workspace!',
              });
              setTimeout(() => setNotification(null), 3000);
            }}
            sheetsConfigStatus={configStatus}
          />
        )}
      </main>

      {/* Footer with Compliance & Regulatory Disclaimers */}
      <footer className="border-t border-white/10 bg-[#070B14] py-8 text-xs text-slate-500">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 space-y-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center space-x-2">
              <span className="font-bold text-slate-300">FinDecision.AI Platform</span>
              <span>•</span>
              <span>BFSI Financial Decision-Making System</span>
            </div>
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setIsMethodologyOpen(true)}
                className="hover:text-slate-300 transition"
              >
                Calculation Methodology
              </button>
              <button
                onClick={() => setIsPrivacyOpen(true)}
                className="hover:text-slate-300 transition"
              >
                Privacy Notice
              </button>
              <span>Server Mode: {configStatus.mode}</span>
            </div>
          </div>

          <p className="text-[11px] leading-relaxed text-slate-400">
            <strong>Mandatory Regulatory Disclosure:</strong> This web application provides
            educational calculations, financial simulations, and decision-support guidance only. It
            does not constitute a formal loan sanction, guaranteed loan approval, binding credit
            offer, or certified investment advice. Loan terms, interest rates, and approval
            probabilities are determined solely by participating lenders and regulated credit
            bureaus following complete institutional underwriting and documentation verification.
          </p>
        </div>
      </footer>

      {/* Modals */}
      <PrivacyNoticeModal isOpen={isPrivacyOpen} onClose={() => setIsPrivacyOpen(false)} />
      <MethodologyModal
        isOpen={isMethodologyOpen}
        onClose={() => setIsMethodologyOpen(false)}
      />
    </div>
  );
}
