/**
 * Type definitions for BFSI Financial Decision-Making Platform
 */

export type Currency = 'USD' | 'INR' | 'EUR' | 'GBP';

export type EmploymentType =
  | 'salaried'
  | 'self-employed'
  | 'business-owner'
  | 'freelancer'
  | 'other';

export type EligibilityStatus =
  | 'Likely Eligible'
  | 'Potentially Eligible'
  | 'Needs Improvement';

export type RiskCategory = 'Low Risk' | 'Moderate Risk' | 'High Risk' | 'Critical Risk';

export type CreditScoreTier =
  | 'Poor'
  | 'Fair'
  | 'Good'
  | 'Very Good'
  | 'Excellent';

export interface FinancialProfile {
  fullName: string;
  age: number;
  monthlyIncome: number;
  monthlyExpenses: number;
  existingEmi: number;
  employmentType: EmploymentType;
  employmentDurationYears: number;
  creditScore: number;
  desiredLoanAmount: number;
  loanTenureMonths: number;
  existingLoansCount: number;
  // Extra fields for credit analyzer
  paymentHistoryPercent?: number;
  creditUtilizationPercent?: number;
  creditAccountsCount?: number;
  creditAgeYears?: number;
  recentHardInquiries?: number;
  outstandingDebt?: number;
  // Extra fields for AI tips
  savingsBalance?: number;
  financialGoals?: string;
}

export interface FactorAssessment {
  name: string;
  score: number; // 0 to 100
  weight: number; // percentage
  status: 'positive' | 'neutral' | 'negative';
  description: string;
}

export interface LoanEligibilityResult {
  status: EligibilityStatus;
  eligibilityScore: number; // 0 to 100
  estimatedEligibleAmount: number;
  requestedAmount: number;
  riskCategory: RiskCategory;
  debtToIncomeRatio: number; // percentage (e.g., 35.5)
  emiToIncomeRatio: number; // percentage
  disposableIncome: number;
  monthlyEstimatedEMI: number;
  keyPositiveFactors: string[];
  keyRiskFactors: string[];
  recommendations: string[];
  factorAssessments: FactorAssessment[];
  calculatedAt: string;
}

export interface AmortizationScheduleItem {
  installmentNumber: number;
  monthYear: string;
  openingBalance: number;
  emi: number;
  principalComponent: number;
  interestComponent: number;
  closingBalance: number;
}

export interface EMICalculationResult {
  monthlyEMI: number;
  principalAmount: number;
  annualInterestRate: number;
  tenureMonths: number;
  totalInterestPayable: number;
  totalRepaymentAmount: number;
  principalPercentage: number;
  interestPercentage: number;
  yearlySchedule: {
    year: number;
    principalPaid: number;
    interestPaid: number;
    remainingBalance: number;
  }[];
  monthlyScheduleSample: AmortizationScheduleItem[];
}

export interface CreditAnalysisResult {
  score: number;
  tier: CreditScoreTier;
  tierColor: string;
  percentile: number;
  healthSummary: string;
  metrics: {
    paymentHistory: { value: number; status: string; impact: string };
    utilization: { value: number; status: string; impact: string };
    historyAge: { value: number; status: string; impact: string };
    accounts: { value: number; status: string; impact: string };
    inquiries: { value: number; status: string; impact: string };
  };
  riskFactors: string[];
  improvementSuggestions: string[];
}

export interface AIAdvisoryResult {
  executiveSummary: string;
  spendingObservations: string[];
  debtManagementAdvice: string[];
  creditImprovementChecklist: string[];
  emiAffordabilityGuidance: string;
  savingsStrategies: string[];
  loanReadinessAssessment: string;
  potentialRisks: string[];
  actionPlan: {
    immediate: string[];
    mediumTerm: string[];
    longTerm: string[];
  };
  disclaimer: string;
  modelUsed: string;
  generatedAt: string;
}

export interface SavedFinancialRecord {
  id: string;
  timestamp: string;
  userName: string;
  monthlyIncome: number;
  monthlyExpenses: number;
  creditScore: number;
  employmentType: string;
  desiredLoanAmount: number;
  loanTenureMonths: number;
  estimatedEligibleAmount: number;
  monthlyEMI: number;
  eligibilityStatus: EligibilityStatus;
  riskCategory: RiskCategory;
  aiSummary: string;
  currency: Currency;
  syncedToGoogleSheets?: boolean;
}

export interface ValidationErrors {
  [key: string]: string | undefined;
}
