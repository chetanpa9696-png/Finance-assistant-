/**
 * Preset profiles for demonstration and instant testing
 */

import { FinancialProfile } from '../types';

export interface ProfilePreset {
  id: string;
  name: string;
  tagline: string;
  category: string;
  profile: FinancialProfile;
}

export const PRESET_PROFILES: ProfilePreset[] = [
  {
    id: 'tech-lead',
    name: 'Sarah Chen',
    tagline: 'Salaried Software Engineer (High Income, High Credit)',
    category: 'Prime Salaried',
    profile: {
      fullName: 'Sarah Chen',
      age: 32,
      monthlyIncome: 8500,
      monthlyExpenses: 2800,
      existingEmi: 450,
      employmentType: 'salaried',
      employmentDurationYears: 5,
      creditScore: 785,
      desiredLoanAmount: 250000,
      loanTenureMonths: 240,
      existingLoansCount: 1,
      paymentHistoryPercent: 100,
      creditUtilizationPercent: 14,
      creditAccountsCount: 7,
      creditAgeYears: 8,
      recentHardInquiries: 1,
      outstandingDebt: 12000,
      savingsBalance: 42000,
      financialGoals: 'Planning home purchase with minimal long-term interest strain.',
    },
  },
  {
    id: 'biz-owner',
    name: 'Marcus Vance',
    tagline: 'Retail Business Owner (Growing Revenue, Moderate DTI)',
    category: 'Self-Employed',
    profile: {
      fullName: 'Marcus Vance',
      age: 41,
      monthlyIncome: 12000,
      monthlyExpenses: 5200,
      existingEmi: 1800,
      employmentType: 'business-owner',
      employmentDurationYears: 7,
      creditScore: 710,
      desiredLoanAmount: 180000,
      loanTenureMonths: 120,
      existingLoansCount: 2,
      paymentHistoryPercent: 96,
      creditUtilizationPercent: 28,
      creditAccountsCount: 6,
      creditAgeYears: 10,
      recentHardInquiries: 2,
      outstandingDebt: 34000,
      savingsBalance: 55000,
      financialGoals: 'Commercial lease renovation and inventory expansion.',
    },
  },
  {
    id: 'freelancer-dev',
    name: 'Alex Rivera',
    tagline: 'Creative Designer & Consultant (Variable Income, Fair Credit)',
    category: 'Freelance & Gig',
    profile: {
      fullName: 'Alex Rivera',
      age: 27,
      monthlyIncome: 4800,
      monthlyExpenses: 2600,
      existingEmi: 650,
      employmentType: 'freelancer',
      employmentDurationYears: 2,
      creditScore: 635,
      desiredLoanAmount: 45000,
      loanTenureMonths: 60,
      existingLoansCount: 2,
      paymentHistoryPercent: 93,
      creditUtilizationPercent: 48,
      creditAccountsCount: 4,
      creditAgeYears: 3,
      recentHardInquiries: 3,
      outstandingDebt: 16500,
      savingsBalance: 8500,
      financialGoals: 'Studio equipment upgrade and emergency buffer build-up.',
    },
  },
  {
    id: 'debt-consolidation',
    name: 'David Patel',
    tagline: 'High DTI Profile Seeking Structured Refinancing',
    category: 'Debt Rebalancing',
    profile: {
      fullName: 'David Patel',
      age: 38,
      monthlyIncome: 5500,
      monthlyExpenses: 3100,
      existingEmi: 1950,
      employmentType: 'salaried',
      employmentDurationYears: 4,
      creditScore: 560,
      desiredLoanAmount: 35000,
      loanTenureMonths: 48,
      existingLoansCount: 4,
      paymentHistoryPercent: 88,
      creditUtilizationPercent: 74,
      creditAccountsCount: 8,
      creditAgeYears: 5,
      recentHardInquiries: 5,
      outstandingDebt: 28000,
      savingsBalance: 2100,
      financialGoals: 'Consolidate multiple high-interest credit lines into single lower EMI.',
    },
  },
];
