/**
 * BFSI Financial Calculations and Scoring Engines
 */

import {
  FinancialProfile,
  LoanEligibilityResult,
  EMICalculationResult,
  CreditAnalysisResult,
  CreditScoreTier,
  RiskCategory,
  EligibilityStatus,
  FactorAssessment,
  AmortizationScheduleItem,
} from '../types';

/**
 * Configurable thresholds and assumptions for financial risk assessment.
 * All thresholds are centralized per BFSI regulatory and underwriting standards.
 */
export const SCORING_CONFIG = {
  // Debt-to-Income (DTI) thresholds
  DTI_EXCELLENT_MAX: 30, // <= 30% is ideal
  DTI_ACCEPTABLE_MAX: 45, // <= 45% is acceptable
  DTI_RISKY_MAX: 55, // > 55% is high risk

  // Credit Score bands
  CREDIT_EXCELLENT_MIN: 800,
  CREDIT_VERY_GOOD_MIN: 740,
  CREDIT_GOOD_MIN: 670,
  CREDIT_FAIR_MIN: 580,
  CREDIT_POOR_MIN: 300,

  // Multipliers for Maximum Loan Eligibility (FOIR based)
  // FOIR = Fixed Obligation to Income Ratio (max 50% of net monthly income for all EMIs)
  MAX_FOIR_PERCENT: 50,
  ANNUAL_BENCHMARK_INTEREST_RATE: 10.5, // Used for FOIR eligibility sizing

  // Factor weights in Loan Eligibility Score (sum = 100)
  WEIGHTS: {
    CREDIT_SCORE: 35,
    DEBT_BURDEN_DTI: 25,
    INCOME_STABILITY: 15,
    EMPLOYMENT_PROFILE: 10,
    AGE_TENURE_ALIGNMENT: 10,
    DESIRED_LOAN_AFFORDABILITY: 5,
  },
};

/**
 * Standard EMI Calculation
 * Formula: EMI = P × r × (1+r)^n / ((1+r)^n - 1)
 * Where:
 * P = Principal loan amount
 * r = Monthly interest rate (Annual Interest Rate / 12 / 100)
 * n = Number of monthly installments
 */
export function calculateEMI(
  principal: number,
  annualInterestRate: number,
  tenureMonths: number
): EMICalculationResult {
  const P = Math.max(0, principal);
  const n = Math.max(1, Math.round(tenureMonths));
  const annualRate = Math.max(0, annualInterestRate);

  let monthlyEMI = 0;
  let totalRepayment = 0;
  let totalInterest = 0;

  if (annualRate === 0) {
    // Zero-interest loan edge case: Straight principal division
    monthlyEMI = P / n;
    totalRepayment = P;
    totalInterest = 0;
  } else {
    const r = annualRate / 12 / 100;
    const compoundFactor = Math.pow(1 + r, n);
    monthlyEMI = (P * r * compoundFactor) / (compoundFactor - 1);
    totalRepayment = monthlyEMI * n;
    totalInterest = Math.max(0, totalRepayment - P);
  }

  // Round values to 2 decimal places
  monthlyEMI = Math.round(monthlyEMI * 100) / 100;
  totalRepayment = Math.round(totalRepayment * 100) / 100;
  totalInterest = Math.round(totalInterest * 100) / 100;

  const principalPercentage = totalRepayment > 0 ? (P / totalRepayment) * 100 : 100;
  const interestPercentage = totalRepayment > 0 ? (totalInterest / totalRepayment) * 100 : 0;

  // Generate Amortization Schedule
  const monthlyScheduleSample: AmortizationScheduleItem[] = [];
  const yearlyScheduleMap: Record<number, { principal: number; interest: number; balance: number }> = {};

  let currentBalance = P;
  const monthlyRate = annualRate / 12 / 100;

  for (let m = 1; m <= n; m++) {
    const interestPart = annualRate === 0 ? 0 : currentBalance * monthlyRate;
    const principalPart = Math.min(currentBalance, monthlyEMI - interestPart);
    const closing = Math.max(0, currentBalance - principalPart);

    const yearNumber = Math.ceil(m / 12);
    if (!yearlyScheduleMap[yearNumber]) {
      yearlyScheduleMap[yearNumber] = { principal: 0, interest: 0, balance: closing };
    }
    yearlyScheduleMap[yearNumber].principal += principalPart;
    yearlyScheduleMap[yearNumber].interest += interestPart;
    yearlyScheduleMap[yearNumber].balance = closing;

    // Keep first 24 months + milestone months in sample table
    if (m <= 24 || m % 12 === 0 || m === n) {
      monthlyScheduleSample.push({
        installmentNumber: m,
        monthYear: `Month ${m}`,
        openingBalance: Math.round(currentBalance * 100) / 100,
        emi: monthlyEMI,
        principalComponent: Math.round(principalPart * 100) / 100,
        interestComponent: Math.round(interestPart * 100) / 100,
        closingBalance: Math.round(closing * 100) / 100,
      });
    }

    currentBalance = closing;
  }

  const yearlySchedule = Object.entries(yearlyScheduleMap).map(([yr, data]) => ({
    year: Number(yr),
    principalPaid: Math.round(data.principal * 100) / 100,
    interestPaid: Math.round(data.interest * 100) / 100,
    remainingBalance: Math.round(data.balance * 100) / 100,
  }));

  return {
    monthlyEMI,
    principalAmount: P,
    annualInterestRate: annualRate,
    tenureMonths: n,
    totalInterestPayable: totalInterest,
    totalRepaymentAmount: totalRepayment,
    principalPercentage: Math.round(principalPercentage * 10) / 10,
    interestPercentage: Math.round(interestPercentage * 10) / 10,
    yearlySchedule,
    monthlyScheduleSample,
  };
}

/**
 * Transparent Loan Eligibility Engine
 * Calculates disposable income, debt burden, multi-factor score, and maximum eligible amount.
 */
export function evaluateLoanEligibility(profile: FinancialProfile): LoanEligibilityResult {
  const {
    monthlyIncome,
    monthlyExpenses,
    existingEmi,
    creditScore,
    age,
    employmentType,
    employmentDurationYears,
    desiredLoanAmount,
    loanTenureMonths,
  } = profile;

  // 1. Disposable Income Calculation
  // Disposable Income = Monthly Income - Monthly Expenses - Existing EMI
  const disposableIncome = Math.max(0, monthlyIncome - monthlyExpenses - existingEmi);

  // 2. Debt-to-Income (DTI) & Fixed Obligation Ratio (FOIR)
  // Total fixed obligations = Existing EMI + Expenses (or just obligations / income)
  const totalExistingDebt = existingEmi;
  const debtToIncomeRatio = monthlyIncome > 0 ? (totalExistingDebt / monthlyIncome) * 100 : 100;
  const foirWithExpenses =
    monthlyIncome > 0 ? ((monthlyExpenses + existingEmi) / monthlyIncome) * 100 : 100;

  // 3. Estimate monthly EMI for requested loan at benchmark rate (10.5% p.a.)
  const benchmarkRate = SCORING_CONFIG.ANNUAL_BENCHMARK_INTEREST_RATE;
  const requestedEMIObj = calculateEMI(desiredLoanAmount, benchmarkRate, loanTenureMonths);
  const monthlyEstimatedEMI = requestedEMIObj.monthlyEMI;
  const projectedDTI =
    monthlyIncome > 0 ? ((existingEmi + monthlyEstimatedEMI) / monthlyIncome) * 100 : 100;
  const emiToIncomeRatio = monthlyIncome > 0 ? (monthlyEstimatedEMI / monthlyIncome) * 100 : 100;

  // 4. Maximum Eligible Loan Calculation (FOIR Model)
  // Max permissible total EMI = (50% of Monthly Income) - Existing EMI
  const maxAllowedMonthlyEMI = Math.max(
    0,
    (monthlyIncome * SCORING_CONFIG.MAX_FOIR_PERCENT) / 100 - existingEmi
  );

  // Reverse calculate principal from max allowable EMI
  let estimatedEligibleAmount = 0;
  if (maxAllowedMonthlyEMI > 0 && loanTenureMonths > 0) {
    const r = benchmarkRate / 12 / 100;
    const n = loanTenureMonths;
    const compoundFactor = Math.pow(1 + r, n);
    estimatedEligibleAmount = (maxAllowedMonthlyEMI * (compoundFactor - 1)) / (r * compoundFactor);
  }

  // Adjust eligibility by credit score coefficient
  let creditMultiplier = 1.0;
  if (creditScore >= 800) creditMultiplier = 1.15;
  else if (creditScore >= 740) creditMultiplier = 1.05;
  else if (creditScore >= 670) creditMultiplier = 0.95;
  else if (creditScore >= 580) creditMultiplier = 0.7;
  else creditMultiplier = 0.4;

  estimatedEligibleAmount = Math.round((estimatedEligibleAmount * creditMultiplier) / 1000) * 1000;

  // 5. Factor Scoring Assessments (0-100 each)
  const factorAssessments: FactorAssessment[] = [];

  // Factor A: Credit Score Factor
  let creditScoreRating = 0;
  if (creditScore >= 800) creditScoreRating = 100;
  else if (creditScore >= 740) creditScoreRating = 88;
  else if (creditScore >= 670) creditScoreRating = 72;
  else if (creditScore >= 580) creditScoreRating = 50;
  else creditScoreRating = 20;

  factorAssessments.push({
    name: 'Credit Score Factor',
    score: creditScoreRating,
    weight: SCORING_CONFIG.WEIGHTS.CREDIT_SCORE,
    status: creditScoreRating >= 75 ? 'positive' : creditScoreRating >= 50 ? 'neutral' : 'negative',
    description: `Credit score of ${creditScore} falls into the ${getCreditScoreTier(creditScore)} tier.`,
  });

  // Factor B: Debt Burden (DTI) Factor
  let dtiScore = 0;
  if (projectedDTI <= 30) dtiScore = 100;
  else if (projectedDTI <= 40) dtiScore = 85;
  else if (projectedDTI <= 50) dtiScore = 65;
  else if (projectedDTI <= 60) dtiScore = 40;
  else dtiScore = 15;

  factorAssessments.push({
    name: 'Debt Burden (DTI) Factor',
    score: dtiScore,
    weight: SCORING_CONFIG.WEIGHTS.DEBT_BURDEN_DTI,
    status: dtiScore >= 70 ? 'positive' : dtiScore >= 50 ? 'neutral' : 'negative',
    description: `Projected total DTI ratio is ${projectedDTI.toFixed(1)}% (including requested EMI).`,
  });

  // Factor C: Income Stability & Disposable Cushion Factor
  const disposableRatio = monthlyIncome > 0 ? (disposableIncome / monthlyIncome) * 100 : 0;
  let incomeStabilityScore = 0;
  if (disposableRatio >= 50) incomeStabilityScore = 100;
  else if (disposableRatio >= 35) incomeStabilityScore = 80;
  else if (disposableRatio >= 20) incomeStabilityScore = 60;
  else if (disposableRatio >= 10) incomeStabilityScore = 40;
  else incomeStabilityScore = 15;

  factorAssessments.push({
    name: 'Income Stability & Cash Buffer',
    score: incomeStabilityScore,
    weight: SCORING_CONFIG.WEIGHTS.INCOME_STABILITY,
    status: incomeStabilityScore >= 70 ? 'positive' : incomeStabilityScore >= 45 ? 'neutral' : 'negative',
    description: `Net unallocated disposable income is ${disposableRatio.toFixed(1)}% of total earnings.`,
  });

  // Factor D: Employment Profile Factor
  let empScore = 70;
  if (employmentType === 'salaried') {
    empScore = employmentDurationYears >= 3 ? 95 : employmentDurationYears >= 1 ? 85 : 70;
  } else if (employmentType === 'business-owner') {
    empScore = employmentDurationYears >= 3 ? 90 : 75;
  } else if (employmentType === 'self-employed') {
    empScore = employmentDurationYears >= 2 ? 80 : 65;
  } else if (employmentType === 'freelancer') {
    empScore = employmentDurationYears >= 2 ? 75 : 55;
  } else {
    empScore = 50;
  }

  factorAssessments.push({
    name: 'Employment Profile & Tenure',
    score: empScore,
    weight: SCORING_CONFIG.WEIGHTS.EMPLOYMENT_PROFILE,
    status: empScore >= 75 ? 'positive' : empScore >= 60 ? 'neutral' : 'negative',
    description: `${employmentType.toUpperCase()} with ${employmentDurationYears} year(s) active track record.`,
  });

  // Factor E: Age & Tenure Factor
  let ageScore = 80;
  const ageAtMaturity = age + loanTenureMonths / 12;
  if (age >= 23 && ageAtMaturity <= 60) ageScore = 95;
  else if (age >= 21 && ageAtMaturity <= 65) ageScore = 80;
  else if (ageAtMaturity <= 70) ageScore = 60;
  else ageScore = 35;

  factorAssessments.push({
    name: 'Age & Retirement Alignment',
    score: ageScore,
    weight: SCORING_CONFIG.WEIGHTS.AGE_TENURE_ALIGNMENT,
    status: ageScore >= 75 ? 'positive' : ageScore >= 50 ? 'neutral' : 'negative',
    description: `Age is ${age} years; maturity reached at approximately ${ageAtMaturity.toFixed(1)} years.`,
  });

  // Factor F: Requested Loan Affordability Factor
  let loanAffordabilityScore = 80;
  if (desiredLoanAmount <= estimatedEligibleAmount) {
    loanAffordabilityScore = 100;
  } else {
    const overRatio = desiredLoanAmount / (estimatedEligibleAmount || 1);
    if (overRatio <= 1.2) loanAffordabilityScore = 70;
    else if (overRatio <= 1.5) loanAffordabilityScore = 45;
    else loanAffordabilityScore = 20;
  }

  factorAssessments.push({
    name: 'Requested Loan Affordability',
    score: loanAffordabilityScore,
    weight: SCORING_CONFIG.WEIGHTS.DESIRED_LOAN_AFFORDABILITY,
    status: loanAffordabilityScore >= 75 ? 'positive' : loanAffordabilityScore >= 50 ? 'neutral' : 'negative',
    description:
      desiredLoanAmount <= estimatedEligibleAmount
        ? 'Requested loan is within projected borrowing capacity.'
        : 'Requested loan exceeds estimated benchmark affordability limits.',
  });

  // 6. Aggregate Total Weighted Score (0 to 100)
  const totalScore = Math.round(
    factorAssessments.reduce((acc, f) => acc + (f.score * f.weight) / 100, 0)
  );

  // 7. Status & Risk Category Determination
  let status: EligibilityStatus = 'Needs Improvement';
  let riskCategory: RiskCategory = 'High Risk';

  if (totalScore >= 78 && creditScore >= 670 && projectedDTI <= 45) {
    status = 'Likely Eligible';
    riskCategory = totalScore >= 88 ? 'Low Risk' : 'Moderate Risk';
  } else if (totalScore >= 55 && creditScore >= 580 && projectedDTI <= 55) {
    status = 'Potentially Eligible';
    riskCategory = 'Moderate Risk';
  } else {
    status = 'Needs Improvement';
    riskCategory = totalScore < 40 || creditScore < 500 ? 'Critical Risk' : 'High Risk';
  }

  // 8. Positive Factors & Risk Flags
  const keyPositiveFactors: string[] = [];
  const keyRiskFactors: string[] = [];
  const recommendations: string[] = [];

  if (creditScore >= 740) {
    keyPositiveFactors.push('Strong credit track record (740+) demonstrates reliable repayment history.');
  }
  if (projectedDTI <= 35) {
    keyPositiveFactors.push(`Healthy DTI profile (${projectedDTI.toFixed(1)}%) allows comfortable debt servicing.`);
  }
  if (disposableIncome >= monthlyIncome * 0.4) {
    keyPositiveFactors.push('Solid disposable cash flow cushion available after all recurring outlays.');
  }
  if (employmentDurationYears >= 3) {
    keyPositiveFactors.push('Established tenure with stable professional/business continuity.');
  }

  if (creditScore < 670) {
    keyRiskFactors.push(`Sub-optimal credit rating (${creditScore}) may lead to higher rate margins or caution.`);
    recommendations.push('Maintain 100% on-time payments for 6 consecutive months to uplift credit scoring.');
  }
  if (projectedDTI > 45) {
    keyRiskFactors.push(`Elevated debt burden: Projected total obligations absorb ${projectedDTI.toFixed(1)}% of income.`);
    recommendations.push('Consider prepaying existing EMIs or extending tenure to lower monthly obligation burden.');
  }
  if (desiredLoanAmount > estimatedEligibleAmount) {
    keyRiskFactors.push(`Requested loan (${desiredLoanAmount}) is above the estimated baseline of ${estimatedEligibleAmount}.`);
    recommendations.push(`Apply with a co-borrower or add a larger down payment to bridge the borrowing gap.`);
  }
  if (ageAtMaturity > 65) {
    keyRiskFactors.push('Tenure extends into customary post-retirement age brackets.');
    recommendations.push('Opt for a shorter loan tenure or demonstrate verifiable post-retirement revenue streams.');
  }

  if (keyPositiveFactors.length === 0) {
    keyPositiveFactors.push('Verifiable active monthly income stream.');
  }
  if (keyRiskFactors.length === 0) {
    keyRiskFactors.push('No critical underwriting flags identified on the provided inputs.');
  }
  if (recommendations.length === 0) {
    recommendations.push('Maintain existing debt servicing cadence and compare institutional APR offerings.');
  }

  return {
    status,
    eligibilityScore: totalScore,
    estimatedEligibleAmount,
    requestedAmount: desiredLoanAmount,
    riskCategory,
    debtToIncomeRatio: Math.round(debtToIncomeRatio * 10) / 10,
    emiToIncomeRatio: Math.round(emiToIncomeRatio * 10) / 10,
    disposableIncome: Math.round(disposableIncome),
    monthlyEstimatedEMI,
    keyPositiveFactors,
    keyRiskFactors,
    recommendations,
    factorAssessments,
    calculatedAt: new Date().toISOString(),
  };
}

/**
 * Credit Score Tier Determination
 */
export function getCreditScoreTier(score: number): CreditScoreTier {
  if (score >= SCORING_CONFIG.CREDIT_EXCELLENT_MIN) return 'Excellent';
  if (score >= SCORING_CONFIG.CREDIT_VERY_GOOD_MIN) return 'Very Good';
  if (score >= SCORING_CONFIG.CREDIT_GOOD_MIN) return 'Good';
  if (score >= SCORING_CONFIG.CREDIT_FAIR_MIN) return 'Fair';
  return 'Poor';
}

/**
 * Educational Credit Score Analyzer
 */
export function analyzeCreditScore(data: {
  score: number;
  paymentHistoryPercent?: number;
  creditUtilizationPercent?: number;
  creditAccountsCount?: number;
  creditAgeYears?: number;
  recentHardInquiries?: number;
  outstandingDebt?: number;
}): CreditAnalysisResult {
  const score = Math.max(300, Math.min(850, Math.round(data.score)));
  const tier = getCreditScoreTier(score);

  const paymentHistory = data.paymentHistoryPercent ?? (score >= 740 ? 99 : score >= 670 ? 95 : 88);
  const utilization = data.creditUtilizationPercent ?? (score >= 740 ? 18 : score >= 670 ? 34 : 65);
  const historyAge = data.creditAgeYears ?? (score >= 740 ? 7 : score >= 670 ? 4 : 2);
  const accounts = data.creditAccountsCount ?? 5;
  const inquiries = data.recentHardInquiries ?? (score >= 740 ? 1 : score >= 670 ? 2 : 5);

  // Percentile estimate
  let percentile = 15;
  let tierColor = '#EF4444';
  if (tier === 'Excellent') {
    percentile = 90;
    tierColor = '#22C55E';
  } else if (tier === 'Very Good') {
    percentile = 72;
    tierColor = '#06B6D4';
  } else if (tier === 'Good') {
    percentile = 55;
    tierColor = '#6366F1';
  } else if (tier === 'Fair') {
    percentile = 30;
    tierColor = '#F59E0B';
  }

  const riskFactors: string[] = [];
  const improvementSuggestions: string[] = [];

  if (paymentHistory < 98) {
    riskFactors.push(`Payment history at ${paymentHistory}% indicates past late payments or missed billing cycles.`);
    improvementSuggestions.push('Set up automated debit payments for all active credit cards and loans to prevent accidental delays.');
  }
  if (utilization > 30) {
    riskFactors.push(`Credit utilization is high at ${utilization}%. Lenders prefer utilization maintained strictly under 30%.`);
    improvementSuggestions.push('Pay balances down before your statement generation date, or request a credit limit expansion.');
  }
  if (inquiries > 3) {
    riskFactors.push(`${inquiries} recent hard inquiries can signal credit hunger to prospective underwriters.`);
    improvementSuggestions.push('Pause applying for new credit lines or unneeded retail store cards for at least 6 months.');
  }
  if (historyAge < 3) {
    riskFactors.push(`Short average credit history (${historyAge} yrs) limits long-term track record visibility.`);
    improvementSuggestions.push('Keep your oldest credit accounts active with tiny recurring transactions to preserve account age.');
  }

  if (riskFactors.length === 0) {
    riskFactors.push('No acute negative factors detected in this credit review.');
  }
  if (improvementSuggestions.length === 0) {
    improvementSuggestions.push('Maintain consistent utilization under 20% and continue on-time monthly payment streaks.');
  }

  const healthSummary =
    tier === 'Excellent' || tier === 'Very Good'
      ? `Your credit profile is exceptionally robust, positioning you favorably for competitive prime lender terms and lower risk margins.`
      : tier === 'Good'
      ? `Your credit health is in good standing with acceptable repayment consistency, though strategic optimization of utilization can boost prime eligibility.`
      : `Your credit health requires focused attention. Addressing revolving debt utilization and ensuring zero missed payments will accelerate recovery.`;

  return {
    score,
    tier,
    tierColor,
    percentile,
    healthSummary,
    metrics: {
      paymentHistory: {
        value: paymentHistory,
        status: paymentHistory >= 99 ? 'Excellent' : paymentHistory >= 95 ? 'Good' : 'Needs Work',
        impact: 'High Impact (35%)',
      },
      utilization: {
        value: utilization,
        status: utilization <= 20 ? 'Optimal' : utilization <= 30 ? 'Acceptable' : 'High Risk',
        impact: 'High Impact (30%)',
      },
      historyAge: {
        value: historyAge,
        status: historyAge >= 6 ? 'Mature' : historyAge >= 3 ? 'Moderate' : 'Young',
        impact: 'Medium Impact (15%)',
      },
      accounts: {
        value: accounts,
        status: accounts >= 5 ? 'Diverse' : 'Basic',
        impact: 'Low Impact (10%)',
      },
      inquiries: {
        value: inquiries,
        status: inquiries <= 1 ? 'Low' : inquiries <= 3 ? 'Moderate' : 'High',
        impact: 'Low Impact (10%)',
      },
    },
    riskFactors,
    improvementSuggestions,
  };
}
