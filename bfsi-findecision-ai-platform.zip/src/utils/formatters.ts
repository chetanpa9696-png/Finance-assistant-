/**
 * Currency & Formatting Helpers for BFSI Platform
 */

import { Currency, EligibilityStatus, RiskCategory } from '../types';

export const CURRENCY_SYMBOLS: Record<Currency, string> = {
  USD: '$',
  INR: '₹',
  EUR: '€',
  GBP: '£',
};

export function formatCurrency(amount: number, currency: Currency = 'USD'): string {
  const symbol = CURRENCY_SYMBOLS[currency] || '$';
  if (isNaN(amount)) return `${symbol}0`;

  if (currency === 'INR') {
    // Indian numbering formatting
    return `${symbol}${amount.toLocaleString('en-IN', {
      maximumFractionDigits: 0,
    })}`;
  }

  return `${symbol}${amount.toLocaleString('en-US', {
    maximumFractionDigits: 0,
  })}`;
}

export function formatPercent(value: number, decimals = 1): string {
  if (isNaN(value)) return '0%';
  return `${value.toFixed(decimals)}%`;
}

export function getStatusBadgeClasses(status: EligibilityStatus): {
  bg: string;
  text: string;
  border: string;
  badge: string;
} {
  switch (status) {
    case 'Likely Eligible':
      return {
        bg: 'bg-emerald-500/10',
        text: 'text-emerald-400',
        border: 'border-emerald-500/30',
        badge: 'bg-emerald-500 text-slate-950 font-semibold',
      };
    case 'Potentially Eligible':
      return {
        bg: 'bg-amber-500/10',
        text: 'text-amber-400',
        border: 'border-amber-500/30',
        badge: 'bg-amber-500 text-slate-950 font-semibold',
      };
    case 'Needs Improvement':
    default:
      return {
        bg: 'bg-rose-500/10',
        text: 'text-rose-400',
        border: 'border-rose-500/30',
        badge: 'bg-rose-500 text-white font-semibold',
      };
  }
}

export function getRiskBadgeClasses(risk: RiskCategory): {
  bg: string;
  text: string;
  border: string;
} {
  switch (risk) {
    case 'Low Risk':
      return {
        bg: 'bg-emerald-500/15',
        text: 'text-emerald-400',
        border: 'border-emerald-500/30',
      };
    case 'Moderate Risk':
      return {
        bg: 'bg-amber-500/15',
        text: 'text-amber-300',
        border: 'border-amber-500/30',
      };
    case 'High Risk':
      return {
        bg: 'bg-orange-500/15',
        text: 'text-orange-400',
        border: 'border-orange-500/30',
      };
    case 'Critical Risk':
    default:
      return {
        bg: 'bg-rose-500/15',
        text: 'text-rose-400',
        border: 'border-rose-500/30',
      };
  }
}
