/**
 * Pure Form Validation Utilities for BFSI Financial Inputs
 */

import { ValidationErrors, FinancialProfile } from '../types';

export function validateRequired(value: unknown, fieldName: string): string | undefined {
  if (value === undefined || value === null || (typeof value === 'string' && value.trim() === '')) {
    return `${fieldName} is required.`;
  }
  return undefined;
}

export function validateNumber(
  value: unknown,
  fieldName: string,
  min = 0,
  max = Number.MAX_SAFE_INTEGER
): string | undefined {
  if (value === undefined || value === null || value === '') {
    return `${fieldName} is required.`;
  }
  const num = Number(value);
  if (isNaN(num)) {
    return `${fieldName} must be a valid numeric value.`;
  }
  if (num < min) {
    return `${fieldName} cannot be less than ${min.toLocaleString()}.`;
  }
  if (num > max) {
    return `${fieldName} cannot exceed ${max.toLocaleString()}.`;
  }
  return undefined;
}

export function validateAge(age: number): string | undefined {
  if (isNaN(age)) return 'Age must be a valid number.';
  if (age < 18) return 'Applicant must be at least 18 years of age.';
  if (age > 85) return 'Age cannot exceed 85 years for loan eligibility assessment.';
  return undefined;
}

export function validateIncome(income: number): string | undefined {
  if (isNaN(income)) return 'Monthly income must be a valid number.';
  if (income <= 0) return 'Monthly income must be greater than zero.';
  if (income > 100000000) return 'Please check the entered monthly income.';
  return undefined;
}

export function validateCreditScore(score: number): string | undefined {
  if (isNaN(score)) return 'Credit score must be a number.';
  if (score < 300 || score > 850) {
    return 'Credit score must fall between standard range 300 and 850.';
  }
  return undefined;
}

export function validateLoanAmount(amount: number): string | undefined {
  if (isNaN(amount)) return 'Desired loan amount must be a number.';
  if (amount < 1000) return 'Minimum loan amount evaluated is 1,000.';
  if (amount > 100000000) return 'Loan amount exceeds institutional retail caps.';
  return undefined;
}

export function validateTenure(months: number): string | undefined {
  if (isNaN(months)) return 'Loan tenure must be a number.';
  if (months < 6) return 'Minimum loan tenure is 6 months.';
  if (months > 480) return 'Maximum loan tenure is 480 months (40 years).';
  return undefined;
}

export function validateLoanEligibilityForm(profile: Partial<FinancialProfile>): {
  isValid: boolean;
  errors: ValidationErrors;
} {
  const errors: ValidationErrors = {};

  // Full name
  const nameErr = validateRequired(profile.fullName, 'Full name');
  if (nameErr) errors.fullName = nameErr;

  // Age
  const ageErr = validateAge(Number(profile.age));
  if (ageErr) errors.age = ageErr;

  // Monthly Income
  const incomeErr = validateIncome(Number(profile.monthlyIncome));
  if (incomeErr) errors.monthlyIncome = incomeErr;

  // Monthly Expenses
  const expensesErr = validateNumber(profile.monthlyExpenses, 'Monthly expenses', 0, 10000000);
  if (expensesErr) errors.monthlyExpenses = expensesErr;

  // Existing EMI
  const emiErr = validateNumber(profile.existingEmi, 'Existing EMI', 0, 10000000);
  if (emiErr) errors.existingEmi = emiErr;

  // Employment Duration
  const durationErr = validateNumber(profile.employmentDurationYears, 'Employment duration', 0, 60);
  if (durationErr) errors.employmentDurationYears = durationErr;

  // Credit Score
  const creditErr = validateCreditScore(Number(profile.creditScore));
  if (creditErr) errors.creditScore = creditErr;

  // Desired Loan Amount
  const loanErr = validateLoanAmount(Number(profile.desiredLoanAmount));
  if (loanErr) errors.desiredLoanAmount = loanErr;

  // Loan Tenure
  const tenureErr = validateTenure(Number(profile.loanTenureMonths));
  if (tenureErr) errors.loanTenureMonths = tenureErr;

  // Cross-field logic check: Expenses + existing EMI > Income
  if (
    !errors.monthlyIncome &&
    !errors.monthlyExpenses &&
    !errors.existingEmi &&
    Number(profile.monthlyExpenses) + Number(profile.existingEmi) >= Number(profile.monthlyIncome)
  ) {
    errors.monthlyExpenses =
      'Total outlays (expenses + EMI) equal or exceed monthly income. Review disposable cash flow.';
  }

  const isValid = Object.keys(errors).length === 0;
  return { isValid, errors };
}
