/**
 * Serverless API Function: Retrieve Financial Records (Netlify/Vercel compatible)
 */

module.exports = async (req, res) => {
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const sampleRecords = [
      {
        id: 'rec-sample-01',
        timestamp: new Date().toISOString(),
        userName: 'Sarah Chen',
        monthlyIncome: 8500,
        monthlyExpenses: 2800,
        creditScore: 785,
        employmentType: 'salaried',
        desiredLoanAmount: 250000,
        loanTenureMonths: 240,
        estimatedEligibleAmount: 295000,
        monthlyEMI: 1890,
        eligibilityStatus: 'Likely Eligible',
        riskCategory: 'Low Risk',
        aiSummary: 'Prime salaried applicant with strong credit history.',
        currency: 'USD',
        syncedToGoogleSheets: false,
      },
    ];

    return res.status(200).json({
      success: true,
      records: sampleRecords,
      count: sampleRecords.length,
    });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to retrieve records' });
  }
};
