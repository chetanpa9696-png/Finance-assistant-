/**
 * Serverless API Function: AI Financial Advisor (Netlify/Vercel compatible)
 */

module.exports = async (req, res) => {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const {
      income = 5000,
      expenses = 2500,
      existingDebt = 10000,
      emi = 400,
      creditScore = 720,
      savings = 20000,
      financialGoals = 'Prudent financial health',
      loanRequirements = {},
      currency = 'USD',
    } = req.body;

    const dti = income > 0 ? (((emi + expenses) / income) * 100).toFixed(1) : '50.0';
    const isPrime = creditScore >= 740;

    // Return structured JSON complying with Section 10, 11, and 28
    const advice = {
      executiveSummary: `Based on your monthly income of ${currency} ${income.toLocaleString()} and outlays of ${currency} ${(expenses + emi).toLocaleString()}, your estimated DTI is ${dti}%. With a credit score of ${creditScore}, you demonstrate ${
        isPrime ? 'solid prime creditworthiness' : 'moderate credit health with room for optimization'
      }.`,
      spendingObservations: [
        `Living expenses consume ${((expenses / (income || 1)) * 100).toFixed(1)}% of gross income.`,
        `Current EMIs account for ${((emi / (income || 1)) * 100).toFixed(1)}% of monthly cash flow.`,
        `Surplus disposable cash is ${currency} ${Math.max(0, income - expenses - emi).toLocaleString()}.`,
      ],
      debtManagementAdvice: [
        'Maintain on-time debt servicing and keep aggregate debt obligations below 40% of income.',
        'Target highest-interest obligations for accelerated prepayment.',
      ],
      creditImprovementChecklist: [
        'Maintain revolving credit utilization strictly under 30%.',
        'Ensure zero missed payment reporting across all active accounts.',
      ],
      emiAffordabilityGuidance: `Under standard institutional 50% FOIR limits, safe new monthly installments are capped around ${currency} ${(income * 0.5 - emi).toFixed(0)}.`,
      savingsStrategies: [
        `Maintain an emergency liquid buffer of at least 3-6 months of baseline living expenses.`,
        `Automate regular monthly deposits into liquid yield reserves.`,
      ],
      loanReadinessAssessment: isPrime
        ? 'High estimated probability of favorable underwriting terms.'
        : 'Moderate estimated readiness; lowering debt ratios will improve terms.',
      potentialRisks: [
        'Higher obligation ratios increase sensitivity to unexpected economic shocks.',
      ],
      actionPlan: {
        immediate: ['Review credit bureau reports for tradeline accuracy.'],
        mediumTerm: ['Reduce revolving balances to optimize credit utilization.'],
        longTerm: ['Maintain clean 12-month on-time payment track record.'],
      },
      disclaimer:
        'This analysis provides educational estimates for financial decision-support and does not constitute guaranteed credit approval, institutional loan sanction, or professional financial advice.',
      modelUsed: 'BFSI Serverless Advisor Engine',
      generatedAt: new Date().toISOString(),
    };

    return res.status(200).json(advice);
  } catch (err) {
    console.error('Serverless AI error:', err);
    return res.status(500).json({ error: 'The AI assistant is temporarily unavailable. Please try again later.' });
  }
};
