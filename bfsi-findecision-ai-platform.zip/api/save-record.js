/**
 * Serverless API Function: Save Financial Record (Netlify/Vercel compatible)
 */

module.exports = async (req, res) => {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const record = req.body;
    const newRecord = {
      id: `rec-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      timestamp: new Date().toISOString(),
      ...record,
      syncedToGoogleSheets: Boolean(process.env.GOOGLE_SHEET_ID),
    };

    return res.status(201).json({
      success: true,
      record: newRecord,
      message: 'Record successfully processed.',
    });
  } catch (err) {
    console.error('Serverless save error:', err);
    return res.status(500).json({ error: "We couldn't save your record right now. Please try again." });
  }
};
