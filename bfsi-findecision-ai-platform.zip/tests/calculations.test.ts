import {
  calculateEMI,
  evaluateLoanEligibility,
  analyzeCreditScore,
} from '../src/utils/calculations';
import { validateLoanEligibilityForm } from '../src/utils/validation';
import { PRESET_PROFILES } from '../src/data/sampleProfiles';

console.log('--- RUNNING BFSI FINANCIAL ENGINE VERIFICATION TESTS ---');

// Test 1: EMI Calculation
console.log('\n[1/4] Testing EMI Calculation Engine...');
const emiStandard = calculateEMI(250000, 8.5, 240);
console.assert(emiStandard.monthlyEMI > 0, 'EMI should be positive');
console.assert(
  emiStandard.totalRepaymentAmount > emiStandard.principalAmount,
  'Total repayment should exceed principal on positive interest'
);
console.assert(
  Math.round(emiStandard.principalPercentage + emiStandard.interestPercentage) === 100,
  'Percentages must sum to 100'
);
console.log(
  `  ✓ Standard Loan: P=250k, r=8.5%, n=240mo -> Monthly EMI: $${emiStandard.monthlyEMI}, Total Interest: $${emiStandard.totalInterestPayable}`
);

// Zero-interest test
const emiZeroInterest = calculateEMI(12000, 0, 12);
console.assert(emiZeroInterest.monthlyEMI === 1000, 'Zero-interest EMI should equal P / n');
console.assert(emiZeroInterest.totalInterestPayable === 0, 'Zero-interest total interest should be 0');
console.log(`  ✓ Zero-Interest Case: P=12k, r=0%, n=12mo -> Monthly EMI: $${emiZeroInterest.monthlyEMI}`);

// Test 2: Loan Eligibility Scoring Engine
console.log('\n[2/4] Testing Loan Eligibility Underwriting Engine...');
const primeProfile = PRESET_PROFILES[0].profile;
const primeResult = evaluateLoanEligibility(primeProfile);
console.assert(primeResult.eligibilityScore >= 75, 'Prime profile should have high score');
console.assert(primeResult.status === 'Likely Eligible', 'Prime applicant should be Likely Eligible');
console.assert(primeResult.riskCategory === 'Low Risk', 'Prime applicant should be Low Risk');
console.log(
  `  ✓ Prime Applicant (${primeProfile.fullName}): Score=${primeResult.eligibilityScore}/100, Status="${primeResult.status}", Risk="${primeResult.riskCategory}"`
);

// Stressed applicant test
const stressedProfile = {
  ...primeProfile,
  monthlyIncome: 3000,
  monthlyExpenses: 2200,
  existingEmi: 900, // total commitments 3100 > 3000 (DTI > 100%)
  creditScore: 540, // poor credit
};
const stressedResult = evaluateLoanEligibility(stressedProfile);
console.assert(
  stressedResult.status === 'Needs Improvement',
  'Stressed applicant should need improvement'
);
console.assert(
  stressedResult.riskCategory === 'High Risk' || stressedResult.riskCategory === 'Critical Risk',
  'Stressed applicant should be classified as High or Critical Risk'
);
console.log(
  `  ✓ High-DTI / Subprime Applicant: Score=${stressedResult.eligibilityScore}/100, Status="${stressedResult.status}", Risk="${stressedResult.riskCategory}"`
);

// Test 3: Credit Score Factor Analyzer
console.log('\n[3/4] Testing Credit Score Diagnostic Tiers...');
const credit300 = analyzeCreditScore({
  score: 450,
  paymentHistoryPercent: 80,
  creditUtilizationPercent: 75,
  creditAccountsCount: 2,
  creditAgeYears: 2,
  recentHardInquiries: 4,
  outstandingDebt: 25000,
});
console.assert(credit300.tier === 'Poor', '450 score should be Poor tier');

const credit820 = analyzeCreditScore({
  score: 820,
  paymentHistoryPercent: 100,
  creditUtilizationPercent: 8,
  creditAccountsCount: 8,
  creditAgeYears: 12,
  recentHardInquiries: 0,
  outstandingDebt: 4000,
});
console.assert(credit820.tier === 'Excellent', '820 score should be Excellent tier');
console.log(
  `  ✓ Credit Tiers: 450 -> "${credit300.tier}" tier, 820 -> "${credit820.tier}" tier`
);

// Test 4: Form & Validation Engine
console.log('\n[4/4] Testing Input Validation Engine...');
const invalidInput = validateLoanEligibilityForm({
  fullName: '',
  age: 15, // under 18
  monthlyIncome: -500, // negative
  monthlyExpenses: 0,
  existingEmi: 0,
  creditScore: 250, // below 300
  desiredLoanAmount: 0,
  loanTenureMonths: 0,
  employmentType: 'salaried',
});
console.assert(!invalidInput.isValid, 'Invalid input should fail validation');
console.assert(invalidInput.errors.fullName !== undefined, 'Missing name should trigger error');
console.assert(invalidInput.errors.age !== undefined, 'Underage applicant should trigger error');
console.assert(invalidInput.errors.monthlyIncome !== undefined, 'Negative income should trigger error');
console.assert(invalidInput.errors.creditScore !== undefined, 'Out-of-range credit score should trigger error');
console.log(`  ✓ Form Validation: Successfully flagged ${Object.keys(invalidInput.errors).length} input violations`);

console.log('\n>>> ALL FINANCIAL ENGINE VERIFICATION TESTS PASSED SUCCESSFULLY! <<<\n');
